export default {
    //html/index.html
    title: "花語星願",
    noAct: "活動未開始",
    actEd: "活動已結束"
};
