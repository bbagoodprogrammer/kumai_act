<template>
  <div class="rule">
    <div class="title">Thể lệ</div>
    <h3>Gương mặt tiêu biểu</h3>
    <h6> Thời gian</h6>
    <p>18h 15/1 – 21h 3/2</p>
    <h6>Hướng dẫn</h6>
    <p>1. Hoàn thành nhiệm vụ ngày và giúp bạn bè, được bạn bè giúp sẽ nhận được cắc.</p>
    <p>2. Dùng cắc để tham gia Đập Chuột mở khoá phần thưởng hoặc rút thưởng tại Vòng Quay May Mắn, đổi phiếu bầu để bầu chọn cho thí sinh dự thi.</p>
    <h3>Ca Sĩ Lôi Cuốn </h3>
    <h6> Thời gian</h6>
    <p>18h 16/1 - 21h 25/1 </p>
    <h6>Hướng dẫn</h6>
    <p>1. Đăng một số bài hát để dự thi, dựa theo điểm Toả Sáng để xếp hạng. Điểm Toả Sáng = điểm mị lực từ phiếu bầu mà bài hát dự thi nhận được + mị lực xu quà bài hát dự thi nhận được.</p>
    <p>2. Có thể nhấn nhận phiếu bầu để chuyển đến sự kiện Gương Mặt Tiêu Biểu Karaoke Now và nhận phiếu.</p>
    <p>3 Túi quà Sô Cô La (50 xu) + Xe Mừng Năm Mới (7 ngày), tỷ lệ trúng thưởng = điểm toả sáng cá nhân trong ngày/tổng điểm toả sáng của top 100 thí sinh.</p>
    <p>4. Top 100 BXH bài hát nhận quà xu nhiều nhất 2019 sẽ được tăng thêm 2% - 10% BXH Toả Sáng Tổng.</p>
    <p>5. Top 3 BXH Toả Sáng sẽ tham gia Đại Nhạc Hội cuối năm và được chia sẻ quà thành tiền mặt.</p>
    <h3>Nam/Nữ Thần Quốc Dân</h3>
    <h6> Thời gian</h6>
    <p>12h 20/1 – 21h 29/1</p>
    <h6>Hướng dẫn</h6>
    <p>1. Nhấn báo danh để tham gia sự kiện, sau khi báo danh mới tính kết quả.</p>
    <p>2. Tại phòng Kara nhận Vé Hỗ Trợ và quà sẽ tăng điểm Ủng Hộ, mời bạn bè hỗ trợ sẽ được tăng thêm điểm, top 100 được vào vòng sau.</p>
    <p>3. Vòng Xếp Hạng chia thành bảng Nam và Nữ Thần, top 15 sẽ vào Chung Kết tại phòng Kara để giành chiến thắng.</p>
    <p>
      4. Top 10 BXH Nam/Nữ Thần sẽ nhận được phần thưởng phong phú, trong đó top 3 sẽ được mời tham gia Đại Nhạc Hội và được chia sẻ quà tặng thành tiền mặt.</p>
    <h3>The Voice Tất Niên</h3>
    <h6>Thời gian báo danh</h6>
    <p>18h 24/1 – 18h 27/1</p>
    <h6>Thời gian chấm điểm</h6>
    <p>18h30 27/1 - 18h 31/1 </p>
    <h6>Hướng dẫn</h6>
    <p>1. Chỉ thí sinh từng đạt top 100 các cuộc thi The Voice trước đây mới được báo danh, mỗi thí sinh chỉ được gửi 1 bài hát đơn ca tham gia cuộc thi.</p>
    <p>2. Hình thức chấm điểm: toàn bộ khán giả bao gồm cả thí sinh dự thi đều được tham gia chấm điểm, mỗi lần chấm từ 1 – 5 sao, 1 sao = 1 điểm.</p>
    <p>3. Xếp hạng dựa vào tổng điểm được chấm.</p>
    <p>4. Top 3 sẽ được mời tham gia Đại Nhạc Hội và được chia sẻ quà tặng thành tiền mặt.</p>
    <h3>Bảng Vàng Gia Tộc</h3>
    <h6> Thời gian</h6>
    <p>12h 26/1 – 21h 3/2</p>
    <h6>Hướng dẫn</h6>
    <p>1. Tộc trưởng và tộc phó nhấn báo danh để tham gia sự kiện, sau khi báo danh mới tính kết quả.</p>
    <p>2. Vốn gia tộc có thể dùng để mở rương và phát thưởng ngẫu nhiên cho thành viên gia tộc, mỗi ngày được mở tối đa 2 rương.</p>
    <p>3. BXH Gia Tộc xếp hạng dựa vào điểm Vinh Quang, top 10 gia tộc sẽ nhận được phần thưởng phong phú, trong đó top 3 sẽ được mời tham gia Đại Nhạc Hội và được chia sẻ quà tặng thành tiền mặt.</p>
    <h3>Đại Nhạc Hội Ngôi Sao</h3>
    <h6> Thời gian</h6>
    <p>19h 14/2 bắt đầu</p>
    <h6>Hướng dẫn</h6>
    <p>1. Tổng cộng 15 thí sinh sẽ được mời tham gia trình diễn từ các sự kiện cuối năm, top 3 gia tộc sẽ do tộc trưởng cử ra dự thi, quà nhận trong nhạc hội sẽ được chia sẽ xu hoặc tiền mặt tương ứng.(Tiền mặt đạt 1 triệu đồng trở lên sẽ phát thưởng tiền mặt, dưới 1 triệu chỉ phát xu)</p>
    <p>2. Trong nhạc hội tặng quà xu bất kỳ sẽ được thưởng 1 Kẹo Que, vào phòng đủ 60 phút sẽ nhận 200 Đậu.</p>
    <p>3. Tại nhạc hội, các loại phần thưởng phong phú như Xe Mừng Năm Mới, VIP, Túi quà, Xu sẽ được gửi tặng không ngừng.</p>
    <h6>Ghi chú:</h6>
    <P>1. Thể lệ cụ thể của từng sự kiện có thể vào trang sự kiện riêng để xem.</P>
    <P>2. Phần thưởng trên trang sự kiện Ngôi Sao Của Năm 2019 Karaoke Now hiển thị toàn bộ phần thưởng của chuỗi sự kiện cuối năm, phần thưởng của từng sự kiện có thể vào trang sự kiện riêng để xem. Quyết định của Karaoke Now là quyết định cuối cùng</P>
    <p>3. Tham gia sự kiện cuối năm nếu nhận nhiều chứng nhận có thể tuỳ ỳ chọn 1.</p>
    <p>4. Mỗi thí sinh cứ đạt top 3 trong chuỗi sự kiện cuối năm sẽ được biểu diễn 1 bài trong nhạc hội cuối năm, tỷ lệ đổi quà thành tiền dựa theo thứ hạng cao nhất đạt được.</p>
    <P class="lastTips"> Quyết định của Karaoke Now là quyết định cuối cùng</P>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss">
body {
  background-color: #050126;
}
.lastTips {
  font-size: 80%;
  color: #776fb6 !important;
  text-align: center;
  margin-top: 1.25rem;
}
.rule {
  padding: 0.52rem 0.33rem;
  .title {
    font-size: 120%;
    text-align: center;
  }
  h3 {
    width: 3.37rem;
    height: 0.68rem;
    line-height: 0.72rem;
    background: url(../../assets/img/ruleTitleBg.png);
    background-size: 100% 100%;
    text-align: center;
    margin: 0.32rem auto;
    font-size: 93%;
  }
  h6 {
    font-size: 86%;
    color: #e16826;
    margin: 0.14rem 0;
  }
  p {
    font-size: 80%;
    color: #fed6a1;
    padding-left: 0.2rem;
  }
}
@import "../../assets/scss/common.scss";
</style>
