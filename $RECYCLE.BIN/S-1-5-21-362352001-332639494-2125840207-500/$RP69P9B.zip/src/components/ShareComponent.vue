<template>
    <div class="shareBox">
         <start-obtain></start-obtain>
         <divide-up-mutton></divide-up-mutton>
    </div>
</template>

<script>
import StartObtain from './StartObtain.vue';
import DivideUpMutton from "./DivideUpMutton" //瓜分羊肉
export default {
    components:{
        StartObtain,
        DivideUpMutton
    }
}
</script>

<style>

</style>
