const result = {
    first_1: "Lớn",
    first_2: "Nhỏ",
    first_3: "Lẻ",
    first_4: "Chẵn",
    second_1: "Điểm 1",
    second_2: "Điểm 2",
    second_3: "Điểm 3",
    second_4: "Điểm 4",
    second_5: "Điểm 5",
    second_6: "Điểm 6",
    third_1: "Tổng điểm 4,17",
    third_2: "Tổng điểm 5,16",
    third_3: "Tổng điểm 6,15",
    third_4: "Tổng điểm 7,14",
    third_5: "Tổng điểm 8,13",
    third_6: "Tổng điểm 9,10,11,12",
}
export default result