const lang = {
  noAct: "Acara  belum dimulai",
  actEd: "Acara udah selesai",
  ok: "Ya"
};
export default lang;
