<template>
  <div class="palying3">
    <turntable></turntable>
  </div>
</template>
<script>
import Turntable from "./Turntable"
export default {
  components: { Turntable }
}
</script>
<style lang="scss">
.palying3 {
  z-index: 20;
}
</style>
