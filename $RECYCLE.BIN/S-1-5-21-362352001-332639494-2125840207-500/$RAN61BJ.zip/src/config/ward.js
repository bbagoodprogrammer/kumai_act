

export const wardName = {
    1: "拼圖碎片①",
    2: "拼圖碎片②",
    3: "拼圖碎片③",
    4: "拼圖碎片④",
    5: "拼圖碎片⑤",
    6: "拼圖碎片⑥",
    7: "10金豆",
    8: "20金豆",
    9: "3金幣",
    10: "20金幣",
    11: "VIP(3天)",
    12: "5%儲值金幣返利券"
}
export const wardImg = {
    1: require("../assets/img/ward1.png"),
    2: require("../assets/img/ward2.png"),
    3: require("../assets/img/ward3.png"),
    4: require("../assets/img/ward4.png"),
    5: require("../assets/img/ward5.png"),
    6: require("../assets/img/ward6.png"),
    7: require("../assets/img/ward7.png"),
    8: require("../assets/img/ward7.png"),
    9: require("../assets/img/ward8.png"),
    10: require("../assets/img/ward8.png"),
    11: require("../assets/img/ward9.png"),
    12: require("../assets/img/ward10.png"),
}