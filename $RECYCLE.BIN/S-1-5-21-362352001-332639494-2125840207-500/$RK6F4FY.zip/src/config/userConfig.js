
const userList = [
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 2,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 3,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    }, {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    },
    {
        rank: 1,
        songs: "??",
        star: "??",
        userinfo: {
            avatar: "",
            nick: "???"
        }
    }
]

export default userList