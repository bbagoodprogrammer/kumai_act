const lang = {
  ActNot: "لم يبدأ النشاط    ", //活動未開始
  ActEnd: "قد انتهى النشاط    ", //活動已結束
  ok: "حسنا    " //我知道啦
};
export default lang;
