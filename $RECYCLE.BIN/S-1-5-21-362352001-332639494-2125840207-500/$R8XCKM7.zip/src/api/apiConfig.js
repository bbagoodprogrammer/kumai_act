// 创建axios实例
import axios from 'axios'
import store from "../store/stores.js"
import getString from "../utils/getString.js"




// const defaultUid = 4979504;
//const defaultToken = '9g0rbTx1xZzvvx12zI7Ox1MIfqxuOLUD2pH4sMdS2Wp68UipYzi5jvF17OISrR6eBwePmxxrKkymtpnTMtkSq0bZ1QJoNkFWE0v1srRMiilfWp-ycMfLe8fTgIMTzLRN';
let token = getString("token")
// let uid = getString("uid")

// var num = 0
// axios.interceptors.request.use(function (config) {  //在请求发出之前进行一些操作
//     num++
//     store.dispatch("setloading",true)
//     return config
// });
// axios.interceptors.response.use(response => {        // 接受请求后num--，判断请求所有请求是否完成
//     num--
//     if (num <= 0) {
//         store.dispatch("setloading",false)    
//     } else {
//         store.dispatch("setloading",true)      
//     }
// })
// axios.create({
//     timeout: 5000          // 请求超时时间
//   });
// axios.defaults.baseURL = "http://activity.17sing.tw"
// axios.defaults.headers.post['Content-Type'] = 'application/json;charset=UTF-8';//配置请求头
//包装axios.get，实现统一处理Loading
function get(url, config) {
    // if (store.state.isShare) {
    //     //分享时识别对应接口，自动切换或直接使用本地数据
    //     for (let regx in share) {
    //         if (url.indexOf(regx) != -1) {
    //             const conf = share[regx];
    //             if (typeof conf == 'string') {
    //                 url = conf;
    //             } else {
    //                 return new Promise(resolve => {
    //                     resolve({
    //                         data: {
    //                             response_status: {error:'', code:0},
    //                             response_data: conf
    //                         }
    //                     });
    //                 });
    //             }
    //         }
    //     }
    // }

    return new Promise((resolve, reject) => {
        store.dispatch("setloading", true) // 打开loading
        axios.get(url, config)
            .then(response => {
                store.dispatch("setloading", false)
                // console.log(response)
                resolve(response);
            })
            .catch(error => {
                store.dispatch("setloading", false)
                reject(error);
            });
    });
}

//获取活动基础信息
function getDefault(t) {
    if (token) {
        return get(`/ye201901/init.php?token=${token}&t=${t}`);
    } else {
        return get(`/ye201901/shareinit.php`);
    }
}
//报名
function singUp(rankState) {
    return get(`/ye201901/register.php?token=${token}&rank_status=${rankState}`)
}

//选票状态
function ticketState() {
    if (token) {
        return get(`/ye201901/dailyticket.php?token=${token}`)
    } else {
        return get(`/ye201901/sharedailyticket.php?token=${token}`)
    }
}

//兑换选票
function getTicket(tid) {
    return get(`/ye201901/getticket.php?token=${token}&tid=${tid}`)
}

//抽奖记录
function getHistroy(from, type) {
    if (type == "more") {
        return axios.get(`/ye201901/getgiftrecord.php?token=${token}&from=${from}`);
    } else {
        return get(`/ye201901/getgiftrecord.php?token=${token}&from=${from}`);
    }

}
//等级礼物状态
function giftState() {
    return get(`/ye201901/userlvlist.php?token=${token}`)
}

//领礼物
function getGift(lv) {
    return get(`/ye201901/getlvgift.php?token=${token}&lv=${lv}`)
}




//抽奖
function go(count) {
    return get(`/ye201901/getgift.php?token=${token}&count=${count}`)
}

//点赞好友列表
function sharePeopl(from) {
    return get(`/ye201901/getfriendsrank.php?token=${token}&from=${from}`)
}

//点赞
function praise(toUid) {
    return get(`/ye201901/praise.php?token=${token}&touid=${toUid}`)
}
//查找好友
function chaUid(uid) {
    return get(`/ye201901/searchfriendsrank.php?token=${token}&search_uid=${uid}`)
}

//查詢打遊戲老鼠狀態
function playGameState(state) {
    return get(`/ye201901/playgame.php?token=${token}`)
}

//統計分享
function shareUpda() {
    return axios.get(`/ye201901/clickrecord.php?token=${token}`)
}

//低版本打地鼠
function diPath() {
    return axios.get(`/ye201901/playrecord.php?token=${token}`)
}
const httpConfig = {
    getDefault,
    getHistroy,
    singUp,
    ticketState,
    getTicket,
    go,
    giftState,
    getGift,
    sharePeopl,
    praise,
    chaUid,
    playGameState,
    shareUpda,
    diPath
}
export default httpConfig