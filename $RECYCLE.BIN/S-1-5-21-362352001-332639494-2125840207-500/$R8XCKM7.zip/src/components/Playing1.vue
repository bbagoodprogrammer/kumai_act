<template>
  <div class="palying1">
    <game></game>
  </div>
</template>
<script>
import Game from "../components/Game"
export default {
  components: { Game }
}
</script>
<style lang="scss"
 scoped>
</style>
