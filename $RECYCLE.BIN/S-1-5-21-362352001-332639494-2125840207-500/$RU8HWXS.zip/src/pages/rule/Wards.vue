<template>
  <div class="wards">
    <p class="activeTime">活動時間:1月24日18:00:00-2月3日20:00:00</p>
    <h5><i class="titleLeft"></i> 作品爭霸榜前10名獎勵<i class="titleRight"></i></h5>
    <div class="wardTop">
      <h5>第一名:</h5>
      <p>禮物王者徽章（31天）+7位靚號+1個月VIP+戰神GTR座駕（28天）+限量超跑作品背包禮物（1888金幣）+3000金幣+3000金豆</p>
      <h5>第二名:</h5>
      <p>禮物王者徽章（31天）+1個月VIP+戰神GTR座駕（21天）+限量超跑作品背包禮物（1888金幣）+2000金幣+2000金豆</p>
      <h5>第三名:</h5>
      <p>禮物王者徽章（31天）+1個月VIP+戰神GTR座駕（21天）+限量超跑作品背包禮物（1888金幣）+1500金幣+1500金豆</p>
      <h5>第四名-第五名:</h5>
      <p>禮物王者徽章（31天）+戰神GTR座駕（14天）+限量超跑背包禮物（1888金幣）+1000金幣+1000金豆</p>
      <h5>第六名-第十名:</h5>
      <p>戰神GTR座駕（7天）+限量超跑背包禮物（1888金幣）+800金幣+800金豆</p>
    </div>
    <h5><i class="titleLeft"></i> K房爭霸榜前10名獎勵<i class="titleRight"></i></h5>
    <div class="kRoomTop">
      <h5>第一名:</h5>
      <p>禮物王者徽章（31天）+7位靚號+1個月VIP+戰神GTR座駕（28天）+限量超跑作品背包禮物（1888金幣）+3000金幣+3000金豆</p>
      <h5>第二名:</h5>
      <p>禮物王者徽章（31天）+1個月VIP+戰神GTR座駕（21天）+限量超跑作品背包禮物（1888金幣）+2000金幣+2000金豆</p>
      <h5>第三名:</h5>
      <p>禮物王者徽章（21天）+1個月VIP+戰神GTR座駕（15天）+限量超跑作品背包禮物（1888金幣）+1500金幣+1500金豆</p>
      <h5>第四名-第五名:</h5>
      <p>禮物王者徽章（14天）+戰神GTR座駕（9天）+限量超跑背包禮物（1888金幣）+1000金幣+1000金豆</p>
      <h5>第六名-第十名:</h5>
      <p>戰神GTR座駕（7天）+限量超跑背包禮物（1888金）+800金幣+800金豆</p>
    </div>
    <h5><i class="titleLeft"></i> 人氣爭霸榜前10名獎勵<i class="titleRight"></i></h5>
    <div class="peopleTop">
      <h5>第一名:</h5>
      <p>人氣王者徽章（31天）+VIP會員（30天）+守護天使背包禮物（600金幣）*1+1500金幣+1500金豆</p>
      <h5>第二名:</h5>
      <p>人氣王者徽章（31天）+VIP會員（15天）+守護天使背包禮物（600金幣）*1+1000金幣+1000金豆</p>
      <h5>第三名:</h5>
      <p>人氣王者徽章（31天）+VIP會員（15天）+守護天使背包禮物（600金幣）*1+800金幣+800金豆</p>
      <h5>第四名-第五名:</h5>
      <p>人氣王者徽章（31天）+VIP會員（15天）+守護天使背包禮物（600金幣）*1+600金幣+600金豆</p>
      <h5>第六名-第十名:</h5>
      <p>VIP會員（28天）+浪漫花車背包禮物（298金幣）*1+300金幣+600金豆</p>
    </div>

    <h5><i class="titleLeft"></i> 金幣返還獎勵<i class="titleRight"></i></h5>
    <div class="fanhuan">
      <p>1、向報名活動後發佈的公開作品贈送新年湯圓（10金幣）、新年紅包（39金幣）、新年快樂（299金幣），次日凌晨返禮物金幣數的5%金幣。如當天贈送1個價值299金幣的新年快樂禮物，則在次日凌晨獎勵15金幣</p>
      <p>2、向報名活動後在K房上麥的用戶贈送新年爆竹（10金幣）、新年福袋（39金幣）、新年舞獅（299金幣）禮物，次日凌晨返禮物金幣數的5%金幣。如當天贈送1個價值299金幣的新年舞獅禮物，則在次日凌晨獎勵15金幣</p>
    </div>

    <h5><i class="titleLeft"></i> 獎勵說明<i class="titleRight"></i></h5>
    <div class="tips">
      <p>1、獲得7位數靚號獎勵，官方號UID10會與您聯繫，在官方提供的靚號庫範圍內篩選確認靚號號碼，以及需要提供未在歡歌平台註冊過的手機號碼進行綁定</p>
      <p>2、該活動獲得的背包禮物獎勵，安卓版本可在我-背包中查看，而且送禮時，選擇背包禮物送出。IOS可前往app store 搜尋最新版本“高歌”，下載使用</p>
    </div>

    <p class="btnMsg">本活動的最終解釋權歸活動主辦方所有</p>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.wards {
  .activeTime {
    color: #faefc9;
    text-align: center;
    font-weight: 0.24rem;
    font-weight: 600;
    margin-top: 0.38rem;
  }

  > h5 {
    text-align: center;
    color: #ffe58a;
    margin: 0.46rem auto 0.18rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 5.9rem;
    .titleLeft {
      width: 1.23rem;
      height: 0.33rem;
      background: url(../../assets/img/titleLeft.png);
      background-size: 100% 100%;
      margin-right: 0.11rem;
    }
    .titleRight {
      width: 1.23rem;
      height: 0.33rem;
      background: url(../../assets/img/titleRight.png);
      background-size: 100% 100%;
      margin-left: 0.11rem;
    }
  }
  .wardTop {
    > h5 {
      color: #ffebc5;
      font-size: 0.21rem;
      margin-top: 0.2rem;
      font-weight: 600;
    }
  }
  .kRoomTop {
    > h5 {
      color: #ffebc5;
      font-size: 0.21rem;
      margin-top: 0.2rem;
      font-weight: 600;
    }
  }
  .fanhuan,
  .tips {
    p {
      margin-top: 0.22rem;
    }
  }
  .peopleTop {
    > h5 {
      color: #ffebc5;
      font-size: 0.21rem;
      margin-top: 0.2rem;
      font-weight: 600;
    }
  }
  p {
    color: #ffebc5;
    font-weight: 600;
    font-size: 0.22rem;
    line-height: 0.36rem;
  }

  .btnMsg {
    margin-top: 1.2rem;
    text-align: center;
    font-size: 0.24rem;
    font-weight: 600;
    color: #ffebc5;
  }
}
</style>
