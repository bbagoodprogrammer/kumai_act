<template>
  <div id="app">
      <summer></summer>
  </div>
</template>

<script>
import Summer from './view/Summer.vue'
export default {
  name: 'App',
  components: {
    Summer
  }
}
</script>

<style lang="scss">
    @import './assets/scss/common.scss';
</style>

