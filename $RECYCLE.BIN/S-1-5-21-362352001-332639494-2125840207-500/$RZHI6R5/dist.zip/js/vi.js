/*!
 * Created by Guohui
 * User: webflash2007@gmail.com
 * Version: 1.0.0
 */
(window.webpackJsonp=window.webpackJsonp||[]).push([["vi"],{rHSA:function(n,i,t){"use strict";t.r(i);var e={title:"Ký hợp đồng"},o={banner:t("rJus")};window._lang=e,window._images=o,e.title&&(document.title=e.title)},rJus:function(n,i,t){n.exports=t.p+"img/5da0a0.png"}},[["rHSA","runtime"]]]);