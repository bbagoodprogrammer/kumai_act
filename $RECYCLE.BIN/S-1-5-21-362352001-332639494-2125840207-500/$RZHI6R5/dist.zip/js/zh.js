/*!
 * Created by Guohui
 * User: webflash2007@gmail.com
 * Version: 1.0.0
 */
(window.webpackJsonp=window.webpackJsonp||[]).push([["zh"],{"WP+K":function(n,t,i){"use strict";i.r(t);i("xBpx");var e={title:"點亮星座"},o={banner:i("f6vO")};window._lang=e,window._images=o,e.title&&(document.title=e.title)},f6vO:function(n,t,i){n.exports=i.p+"img/df23e5.png"},xBpx:function(n,t,i){}},[["WP+K","runtime"]]]);