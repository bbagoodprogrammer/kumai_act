const dayNum = {
    20191210: { num: 1, str: 12.10 }
}