const result = {
    first_1: "Besar",
    first_2: "Kecil",
    first_3: "Tunggal",
    first_4: "Ganda",
    second_1: "Nilai dadu 1",
    second_2: "Nilai dadu 2",
    second_3: "Nilai dadu 3",
    second_4: "Nilai dadu 4",
    second_5: "Nilai dadu 5",
    second_6: "Nilai dadu 6",
    third_1: "Total skor 4,17",
    third_2: "Total skor  5,16",
    third_3: "Total skor  6,15",
    third_4: "Total skor  7,14",
    third_5: "Total skor  8,13",
    third_6: "Total skor  9,10,11,12",
}
export default result