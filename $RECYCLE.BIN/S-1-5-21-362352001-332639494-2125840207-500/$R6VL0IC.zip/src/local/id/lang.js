export default {
    //html/index.html
    title: 'Menandatangani kontrak',

    //html/app_share.ejs
    share_title: 'Menandatangani kontrak',
    share_desc: '',
}