export default {
    //html/index.html
    title: 'Ký hợp đồng',

    //html/app_share.ejs
    share_title: 'Ký hợp đồng',
    share_desc: '',
}