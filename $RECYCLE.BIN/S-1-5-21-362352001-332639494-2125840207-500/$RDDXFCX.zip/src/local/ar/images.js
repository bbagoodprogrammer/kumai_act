export default {
    share: require('./img/share.png'),
}