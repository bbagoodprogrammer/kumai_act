export default {
    //html/index.html
    title: '\u200E',
}