/*!
 * Created by Guohui
 * User: webflash2007@gmail.com
 * Version: 1.0.0
 */
(window.webpackJsonp=window.webpackJsonp||[]).push([["en"],{rKIV:function(t,n,e){"use strict";e.r(n);var i={title:"Vmeet",login_title:"Agent login",admin_title:"Agent admin"};window._lang=i,i.title&&(document.title=i.title)}},[["rKIV","runtime"]]]);