const lang = {
    noAct: 'لم يبدأ النشاط',
    actEd: 'قد انتهى النشاط ',
    ok: 'عرفت    '
}
export default lang