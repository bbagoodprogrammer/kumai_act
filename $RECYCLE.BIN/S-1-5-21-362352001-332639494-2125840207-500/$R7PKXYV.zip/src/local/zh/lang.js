export default {
    //html/index.html
    title: "花語星願"
};
