const lang = {
    ok: 'تأكيد    ',
    noAct: 'لم يبدأ النشاط    ',
    actEnd: 'قد انتهى النشاط    '
}
export default lang