const giftArr = [
    {
        name: 'صندوق الكنز        '
    },
    {
        name: 'تاج علاء الدين        '
    },
    {
        name: 'سيف سحري        '
    },
    {
        name: 'جان المصباح السحري        '
    },
    {
        name: 'سجادة طائرة        '
    },
    {
        name: 'أنت عسل        '
    },
    {
        name: 'صوت رائع        ' // 7
    },
    {
        name: 'بوق سحري        '
    },
    {
        name: 'خاتم سحري        '
    },
    {
        name: 'perfume        '
    },
    {
        name: 'الماء السحري        '
    },
    {
        name: 'ثروة كبيرة        '
    },
    {
        name: 'شوكولاتة        '
    },
    {
        name: 'أيس كريم        '
    },
    {
        name: 'كيوت        '
    },
    {
        name: 'سيارة التاج        '
    },
]
export default giftArr