export default {
    title: '任務',
    my_total_bean:'我的金豆總額',
    news_task:'新手任務',
    is_get:'已領取',
    get:'點擊領取',
    go:'去完成',
    days_task:'日常任務',
    get_beans:'領取金豆',
}