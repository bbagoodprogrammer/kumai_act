export default {
    //html/index.html
    title: 'Nhiệm vụ',
    my_total_bean:'Đậu của Tôi',
    news_task:'Nhiệm vụ',
    is_get:'Đã nhận',
    get:'Nhấn nhận',
    go:'Hoàn thành',
    days_task:'Nhiệm vụ ngày',
    get_beans:'Nhận Đậu',
}