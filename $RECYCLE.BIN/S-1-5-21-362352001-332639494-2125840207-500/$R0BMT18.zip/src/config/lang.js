const lang = {
    noAct: 'Sự kiện chưa mở',
    actEd: 'Sự kiện đã kết thúc',
    ok: ' Tôi biết rồi!'
}
export default lang