const lang = {
    noAct: '活動未開始',
    actEd: '活動已結束',
    ok: '確認'
}
export default lang