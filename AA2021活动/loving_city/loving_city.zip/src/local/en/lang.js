export default {
    //html/index.html
    title: 'Sign with us',
}