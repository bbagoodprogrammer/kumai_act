export default {
    //html/index.html
    title: 'Ký hợp đồng',
}