export default {
    //html/index.html
    title: '簽約',
}