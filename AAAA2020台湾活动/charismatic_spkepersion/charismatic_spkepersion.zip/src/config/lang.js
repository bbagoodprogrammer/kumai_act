const lang = {
    noAct: '活動未開始',
    actEd: '活動已結束',
    ok: '我知道啦'
}
export default lang