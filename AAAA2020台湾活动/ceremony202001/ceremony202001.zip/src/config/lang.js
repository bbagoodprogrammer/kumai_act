const Lang = {
    ActNot: '活動未開始',
    ActEnd: '活動已結束',
    ok: '我知道啦',
    GameB: '盛典幣：',
    fiveTips: '恭喜您連抽5次獲得以下獎品',
    noCointTitle: '無法抽獎',
    noCoinsTips4: '您的盛典幣餘額不足，無法抽獎',
    noCoinsTips2: '快去賺取盛典幣吧！',
    noRank: '未上榜',
    myScore: '我的歡樂值：',
    lastRankScore: '距離上榜還差歡樂值：'
}
export default Lang