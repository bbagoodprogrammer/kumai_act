export default {
    // banner: require('./img/banner.png'),
    // card: require('./img/card.png'),
    skillImg: require('./img/skillImg.png'),
}