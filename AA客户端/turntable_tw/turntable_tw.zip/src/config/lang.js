const vietnamLang = {
    superbandit:"Máy Bar Siêu Khổng Lồ", //超級老虎機
    triple_prize:"Thưởng gấp ba tới tấp",  //3倍獎勵抽不停
    activity_time:"Thời gian 18h 19/7~21h 2/8",  // 活动时间
    activity_rules:"Thể lệ>>", //活动规则》》
    draw_record:"Lịch sử>>",  //抽獎記錄>>
    my_knapsack:"Túi>>",  //我的背包
    stored_value:"Nạp ngay",  //前去储值
    draw_time:"Thời gian", //抽奖时间
    winning_prizes:"Nhận thưởng",  //获得奖品
}
export default vietnamLang