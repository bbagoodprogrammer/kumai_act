export default {
    //html/index.html
    title: 'समझौता',

    //html/app_share.ejs
    share_title: 'समझौता',
    share_desc: '',
}