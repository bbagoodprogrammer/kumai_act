/*!
 * Created by Tang Guohui
 * User: tang_guohui@qq.com
 */
(window.webpackJsonp = window.webpackJsonp || []).push([
    ["share"], {
        Gfup: function (t, s, i) {
            "use strict";
            i.r(s);
            i("5+t+"), i("VLrD"), i("ls82");
            var a = i("Kw5r"),
                e = [function () {
                    var t = this.$createElement,
                        s = this._self._c || t;
                    return s("div", {
                        staticClass: "mid"
                    }, [s("div", {
                        staticClass: "icon"
                    })])
                }, function () {
                    var t = this,
                        s = t.$createElement,
                        i = t._self._c || s;
                    return i("ul", {
                        staticClass: "ul"
                    }, [i("li", [t._v("你會變成小星星")]), t._v(" "), i("li", [t._v("在比人的世界裡一閃一閃亮晶晶")]), t._v(" "), i("li", [t._v("所以我要睡著之前")]), t._v(" "), i("li", [t._v("把你關進我眼睛")]), t._v(" "), i("li", [t._v("天天如此一如既往")])])
                }, function () {
                    var t = this.$createElement,
                        s = this._self._c || t;
                    return s("ul", [s("li", [this._v("我們在音覓相遇相識")]), this._v(" "), s("li", [this._v("距離不阻礙緣分")]), this._v(" "), s("li", [this._v("希望得到你的祝福")])])
                }, function () {
                    var t = this,
                        s = t.$createElement,
                        i = t._self._c || s;
                    return i("ul", {
                        staticClass: "ul"
                    }, [i("li", [t._v("喜歡裹著很厚的焦糖的爆米花")]), t._v(" "), i("li", [t._v("喜歡雨天厚厚的棉被")]), t._v(" "), i("li", [t._v("喜歡圖書館裡的詩集")]), t._v(" "), i("li", [t._v("喜歡黃昏時分農曆的晚霞")]), t._v(" "), i("li", [t._v("喜歡四季更替的季風訊息")]), t._v(" "), i("li", [t._v("但還是最喜歡你")])])
                }, function () {
                    var t = this.$createElement,
                        s = this._self._c || t;
                    return s("ul", [s("li", [this._v("我們在音覓相遇相識")]), this._v(" "), s("li", [this._v("距離不阻礙緣分")]), this._v(" "), s("li", [this._v("希望得到你的祝福")])])
                }, function () {
                    var t = this,
                        s = t.$createElement,
                        a = t._self._c || s;
                    return a("div", {
                        staticClass: "gifts"
                    }, [a("div", [a("img", {
                        attrs: {
                            src: i("tNG6"),
                            alt: ""
                        }
                    }), t._v(" "), a("p", [t._v("甜蜜之戀-戒指")])]), t._v(" "), a("div", [a("img", {
                        attrs: {
                            src: i("kHVg"),
                            alt: ""
                        }
                    }), t._v(" "), a("p", [t._v("新郎新娘頭像框")])]), t._v(" "), a("div", [a("img", {
                        attrs: {
                            src: i("qdaB"),
                            alt: ""
                        }
                    }), t._v(" "), a("p", [t._v("豐富金幣")])])])
                }, function () {
                    var t = this.$createElement,
                        s = this._self._c || t;
                    return s("div", {
                        staticClass: "mid"
                    }, [s("div", {
                        staticClass: "icon"
                    })])
                }, function () {
                    var t = this.$createElement,
                        s = this._self._c || t;
                    return s("div", {
                        staticClass: "cp_info"
                    }, [s("div", {
                        staticClass: "avatar"
                    }, [s("img", {
                        attrs: {
                            src: i("DmyW"),
                            alt: ""
                        }
                    })]), this._v(" "), s("p", [this._v("未來的你")])])
                }, function () {
                    var t = this.$createElement,
                        s = this._self._c || t;
                    return s("div", {
                        staticClass: "no_tips"
                    }, [this._v("我們將音覓相遇相識"), s("br"), this._v("距離不阻礙緣分")])
                }, function () {
                    var t = this,
                        s = t.$createElement,
                        a = t._self._c || s;
                    return a("div", {
                        staticClass: "gifts"
                    }, [a("div", [a("img", {
                        attrs: {
                            src: i("tNG6"),
                            alt: ""
                        }
                    }), t._v(" "), a("p", [t._v("甜蜜之戀-戒指")])]), t._v(" "), a("div", [a("img", {
                        attrs: {
                            src: i("kHVg"),
                            alt: ""
                        }
                    }), t._v(" "), a("p", [t._v("新郎新娘頭像框")])]), t._v(" "), a("div", [a("img", {
                        attrs: {
                            src: i("qdaB"),
                            alt: ""
                        }
                    }), t._v(" "), a("p", [t._v("豐富金幣")])])])
                }],
                n = i("L2JU"),
                r = i("rA1G"),
                v = i("IBle"),
                c = i("7Qib"),
                _ = i("+MiA"),
                l = i("Ofg6"),
                o = (i("8SHQ"), i("agfS")),
                u = i("bw5Y"),
                p = Object.assign || function (t) {
                    for (var s = 1; s < arguments.length; s++) {
                        var i = arguments[s];
                        for (var a in i) Object.prototype.hasOwnProperty.call(i, a) && (t[a] = i[a])
                    }
                    return t
                };
            var d, f, m = Object(c.b)("uid"),
                h = (Object(c.b)("token"), {
                    mixins: [r.a],
                    data: function () {
                        return {
                            res: {}
                        }
                    },
                    computed: p({}, Object(n.b)(["loading", "coverRank"])),
                    mounted: (d = regeneratorRuntime.mark(function t() {
                        var s, i, a, e;
                        return regeneratorRuntime.wrap(function (t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, Object(_.e)(m);
                                case 2:
                                    s = t.sent, i = s.data, a = i.response_status, e = i.response_data, console.log(e), a && 0 === a.code ? this.res = e : this.$alert(a.error);
                                case 6:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }), f = function () {
                        var t = d.apply(this, arguments);
                        return new Promise(function (s, i) {
                            return function a(e, n) {
                                try {
                                    var r = t[e](n),
                                        v = r.value
                                } catch (t) {
                                    return void i(t)
                                }
                                if (!r.done) return Promise.resolve(v).then(function (t) {
                                    a("next", t)
                                }, function (t) {
                                    a("throw", t)
                                });
                                s(v)
                            }("next")
                        })
                    }, function () {
                        return f.apply(this, arguments)
                    }),
                    methods: {
                        openApp: u.a,
                        getAvatar: function (t) {
                            return t || i("DmyW")
                        },
                        open_app: function () {
                            this.openApp()
                        },
                        dataParse: function (t) {
                            return console.log(t), t.response_data.record || []
                        },
                        timeInterval: function (t) {
                            if (t > 0) {
                                var s = new Date(1e3 * t),
                                    i = s.getFullYear(),
                                    a = s.getMonth() + 1,
                                    e = s.getDate(),
                                    n = s.getHours(),
                                    r = s.getMinutes() >= 10 ? s.getMinutes() : "0" + s.getMinutes();
                                s.getSeconds();
                                return n + ":" + r + " " + e + "/" + a + "/" + i
                            }
                        }
                    },
                    components: {
                        Loading: v.a,
                        ScrollLoadList: o.a
                    }
                }),
                g = (i("tux1"), i("KHd+")),
                C = Object(g.a)(h, function () {
                    var t = this,
                        s = t.$createElement,
                        i = t._self._c || s;
                    return i("div", {
                        staticClass: "record"
                    }, [i("div", {
                        staticClass: "con"
                    }, [!t.res.cp_nick ? i("div", {
                        staticClass: "love_box"
                    }, [i("div", {
                        staticClass: "top"
                    }, [i("div", {
                        staticClass: "my_info"
                    }, [i("div", {
                        staticClass: "avatar"
                    }, [i("img", {
                        attrs: {
                            src: t.getAvatar(t.res.avatar),
                            alt: ""
                        }
                    })]), t._v(" "), i("p", [t._v(t._s(t.res.nick))])]), t._v(" "), t._m(0), t._v(" "), i("div", {
                        staticClass: "cp_info"
                    }, [i("div", {
                        staticClass: "avatar"
                    }, [i("img", {
                        attrs: {
                            src: t.getAvatar(t.res.cp_avatar),
                            alt: ""
                        }
                    })]), t._v(" "), i("p", [t._v(t._s(t.res.cp_nick))])])]), t._v(" "), "sweet" == t.res.team ? i("div", {
                        staticClass: "is_sweet"
                    }, [t._m(1), t._v(" "), t._m(2), t._v(" "), i("p", {
                        staticClass: "sign"
                    }, [t._v("— 甜系CP")])]) : i("div", {
                        staticClass: "is_salt"
                    }, [t._m(3), t._v(" "), t._m(4), t._v(" "), i("p", {
                        staticClass: "sign"
                    }, [t._v("— 鹽系CP")])]), t._v(" "), i("div", {
                        staticClass: "bottom"
                    }, [t._m(5), t._v(" "), i("div", {
                        staticClass: "btn",
                        on: {
                            click: function (s) {
                                return t.open_app()
                            }
                        }
                    }, [t._v("祝福他們")]), t._v(" "), i("p", {
                        staticClass: "slogan"
                    }, [t._v("從此遇見一個人，便知道了另一種人生，也溫暖了兩個靈魂")])])]) : i("div", {
                        staticClass: "love_box_null"
                    }, [i("div", {
                        staticClass: "top"
                    }, [i("div", {
                        staticClass: "my_info"
                    }, [i("div", {
                        staticClass: "avatar"
                    }, [i("img", {
                        attrs: {
                            src: t.getAvatar(t.res.avatar),
                            alt: ""
                        }
                    })]), t._v(" "), i("p", [t._v(t._s(t.res.nick))])]), t._v(" "), t._m(6), t._v(" "), t._m(7)]), t._v(" "), t._m(8), t._v(" "), i("div", {
                        staticClass: "bottom"
                    }, [t._m(9), t._v(" "), i("div", {
                        staticClass: "btn",
                        on: {
                            click: function (s) {
                                return t.open_app()
                            }
                        }
                    }, [t._v("和他/她相識")]), t._v(" "), i("p", {
                        staticClass: "slogan"
                    }, [t._v("從此遇見一個人，便知道了另一種人生，也溫暖了兩個靈魂")])])])]), t._v(" "), i("loading", {
                        attrs: {
                            show: t.loading
                        }
                    })], 1)
                }, e, !1, null, null, null).exports,
                b = i("Q2AE");
            a.a.use(l.b), a.a.config.productionTip = !1, new a.a({
                el: "#app",
                store: b.a,
                components: {
                    Page: C
                },
                render: function (t) {
                    return t(C)
                }
            })
        },
        J6qz: function (t, s, i) {},
        tux1: function (t, s, i) {
            "use strict";
            var a = i("J6qz");
            i.n(a).a
        }
    },
    [
        ["Gfup", "runtime", "vendor", "common"]
    ]
]);