const vietnamLang = {
    superbandit: "超級老虎機", //超級老虎機
    triple_prize: "Thưởng gấp ba tới tấp",  //3倍獎勵抽不停
    activity_time: "Thời gian 18h 19/7~21h 2/8",  // 活动时间
    activity_rules: "活動規則", //活动规则》》
    draw_record: "抽獎記錄",  //抽獎記錄>>
    my_knapsack: "我的背包",  //我的背包
    stored_value: "Nạp ngay",  //前去储值
    draw_time: "Thời gian", //抽奖时间
    winning_prizes: "Nhận thưởng",  //获得奖品
}
export default vietnamLang