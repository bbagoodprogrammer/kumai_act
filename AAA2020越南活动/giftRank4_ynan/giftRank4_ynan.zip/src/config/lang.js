const lang = {
    noAct: 'Sự kiện chưa mở',
    actEd: 'Sự kiện đã kết thúc',
    ok: 'Xác nhận'
}
export default lang