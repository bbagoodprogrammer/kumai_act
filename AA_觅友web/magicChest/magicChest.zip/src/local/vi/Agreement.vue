<template>
    <div class="page pageAgreement">
        <h5>Thoả thuận người dùng KaraokeNow</h5>
        <p>&quot;Thoả thuận người dùng Karaoke Now&quot; (sau đây gọi tắt là &quot;Thỏa thuận này&quot;) được ký kết giữa người dùng (nghĩa là người sáng tạo hoặc chủ phòng trên nền tảng này, sau đây gọi tắt là &quot;người dùng&quot;) và chủ sở hữu của nền tảng này (sau đây gọi là &quot;nền tảng / nền tảng này&quot;). Thỏa thuận này có hiệu lực như hợp đồng. Người dùng phải đọc kỹ và hiểu đầy đủ các điều khoản và điều kiện, đặc biệt là các điều khoản miễn trừ hoặc giới hạn trách nhiệm pháp lý và các thỏa thuận riêng để mở hoặc sử dụng dịch vụ và chọn chấp nhận hoặc không chấp nhận. Các hạn chế và điều khoản miễn trừ có thể được in đậm để nhắc nhở người dùng chú ý. Nếu người dùng là trẻ vị thành niên, vui lòng đọc kỹ và hiểu đầy đủ thỏa thuận này với người giám hộ hợp pháp và chỉ sử dụng các dịch vụ được cung cấp bởi nền tảng này sau khi có được sự đồng ý của người giám hộ hợp pháp. Nếu người dùng là người giám hộ hợp pháp của trẻ vị thành niên, hy vọng sẽ thiết lập thời gian giải trí một cách hợp lý và bồi dưỡng thói quen giải trí lành mạnh cho trẻ em.</p>
        <p>Trừ khi người dùng đã đọc và chấp nhận hoàn toàn tất cả các điều khoản của thỏa thuận này, nếu không người dùng không được sử dụng các dịch vụ được cung cấp bởi nền tảng này dưới bất kỳ hình thức nào. Nếu người dùng nhấn chấp nhận, đồng ý, tiếp theo, hoặc người dùng đăng ký và sử dụng các dịch vụ của nền tảng, có nghĩa là người dùng đã hiểu đầy đủ và chấp nhận bị ràng buộc bởi bên còn lại trong thỏa thuận này.</p>
        <p>Nếu người dùng có ý kiến , đề xuất về thỏa thuận này hoặc các dịch vụ được cung cấp bởi nền tảng này, có thể liên hệ với bộ phận chăm sóc khách hàng của nền tảng này và chúng tôi sẽ cung cấp cho người dùng sự trợ giúp cần thiết.</p>
        <h6>I. Quy định về tài khoản của nền tảng</h6>
        <p>1. Đăng ký tài khoản</p>
        <p>1.1 Người dùng đăng ký tài khoản của nền tảng với thông tin thật và hợp lệ, bao gồm cập nhật liên tục thông tin tài khoản theo trạng thái thay đổi thông tin cá nhân, nếu người dùng cung cấp bất kỳ thông tin sai, không đúng, lỗi thời, không đầy đủ hoặc khi nền tảng có lý do hợp lý để nghi ngờ những thông tin đã nêu trên sai, không đúng sự thật, lỗi thời hoặc không đầy đủ, nền tảng có quyền đình chỉ một phần hoặc chấm dứt dịch vụ tài khoản của người dùng.</p>
        <p>1.2 Khi người dùng truy cập, duyệt và sử dụng các dịch vụ được cung cấp bởi tài khoản nền tảng, có nghĩa họ đã chấp nhận các điều khoản của thỏa thuận dịch vụ này và đồng ý bị ràng buộc bởi thỏa thuận dịch vụ này, nếu người dùng không đồng ý với các điều khoản của thỏa thuận này, vui lòng dừng đăng ký và ngừng sử dụng nền tảng.</p>
        <p>1.3 Người dùng hiểu và chấp nhận tài khoản cùn thông tin đã đăng ký do người dùng đặt, không vi phạm luật pháp và quy định cũng như các quy tắc có liên quan của nền tảng như tên tài khoản, hình đại diện và hồ sơ của người dùng không được xuất hiện thông tin bất hợp pháp (bao gồm nhưng không giới hạn trong việc mạo danh họ tên, biệt danh của người khác, phông chữ, hình đại diện, vv đủ để gây nhầm lẫn). Người dùng phải tuân thủ luật pháp và quy định có liên quan trong quá trình đăng ký, sử dụng, đồng thời không được thực hiện bất kỳ hành vi nào xâm phạm lợi ích của đất nước, làm tổn hại đến quyền và lợi ích hợp pháp của người khác và gây nguy hại cho đạo đức xã hội.</p>
        <p>2. Sử dụng và lưu trữ tài khoản</p>
        <p>2.1 Nền tảng có quyền xem xét tính xác thực, hợp lệ và hợp pháp của thông tin cá nhân do người dùng đăng ký cung cấp và thực hiện các biện pháp hợp lý để bảo vệ tính bảo mật của tài khoản người dùng, người dùng phải lưu giữ và sử dụng tài khoản và mật khẩu của mình một cách an toàn, bao gồm việc sau mỗi lần sử dụng, bạn nên kết thúc đăng nhập tài khoản và không được tiết lộ, v.v., nếu không, tài khoản nền tảng của người dùng có thể không được bảo vệ an toàn, nếu người dùng thấy rằng tài khoản hoặc mật khẩu của mình đã bị người khác sử dụng bất hợp pháp hoặc có bất thường, người dùng có quyền thông báo cho nền tảng để nền tảng thực hiện các biện pháp bảo vệ.</p>
        <p>2.2 Người dùng có quyền và trách nhiệm đối với hành vi của tài khoản được lưu giữ sau khi đăng nhập theo luật, vì vậy nền tảng này không chịu bất kỳ trách nhiệm nào đối với bất kỳ tổn thất hoặc thiệt hại nào xảy ra từ hành vi này.</p>
        <p>2.3 Nền tảng cấm người dùng giao dịch tài khoản của nền tảng. Nếu tình huống như vậy xảy ra, nền tảng có quyền thu hồi tài khoản nền tảng của giao dịch bởi người dùng. Nếu khi tài khoản bị thu hồi vẫn còn số dư nạp tiền hoặc các vật phẩm ảo khác, chúng sẽ bị xóa ngay lập tức và sẽ không được quy đổi trong hoặc ngoài nền tảng. Nếu có bất kỳ tranh chấp nào gây ra bởi giao dịch tài khoản nền tảng của người dùng, nền tảng này không chịu bất kỳ trách nhiệm nào.</p>
        <h6>II. Bảo vệ quyền riêng tư và thông tin</h6>
        <p>1. Quyền riêng tư và bảo vệ thông tin người dùng</p>
        <p>1.1 Nền tảng yêu cầu người dùng cung cấp thông tin liên quan đến danh tính cá nhân của mình và sẽ thực hiện các biện pháp cần thiết để bảo vệ tính bảo mật thông tin cá nhân của người dùng.</p>
        <p>1.2 Trên cơ sở tuân thủ các yêu cầu của thỏa thuận này, nền tảng này sẽ bảo vệ hoàn toàn quyền riêng tư cá nhân của người dùng. Ngoại trừ các lý do sau, nếu không có sự cho phép, nền tảng này sẽ không cung cấp hoặc tiết lộ thông tin cá nhân cá nhân cho bất kỳ bên thứ ba nào:</p>
        <p class="list">
            a) Người dùng hoặc người giám hộ của người dùng ủy quyền hoặc cho phép tiết lộ thông tin của mình;
            <br />b) Theo yêu cầu của pháp luật và các quy định có liên quan;
            <br />c) Vì mục đích đảm bảo an toàn hoặc lợi ích của cá nhân và xã hội;
            <br />d) Duy trì các quyền và lợi ích hợp pháp của nền tảng này;
            <br />e) Các yêu cầu hợp pháp khác có liên quan.
        </p>
        <p>2. Nền tảng có thể thu thập thông tin cá nhân của người dùng khi cung cấp dịch vụ. Để cung cấp dịch vụ tốt hơn, nền tảng cũng có thể thu thập và phân tích thông tin kỹ thuật và trạng thái sử dụng của người dùng. Người dùng ủy quyền cho nền tảng lấy và sử dụng hợp lý các thông tin trên. Nền tảng hứa tuân thủ các yêu cầu pháp lý, ngoại trừ việc tiết lộ theo yêu cầu của pháp luật hoặc không thể khôi phục dữ liệu gốc của cá nhân (như dữ liệu thống kê dựa trên &quot;dữ liệu lớn&quot;).</p>
        <p>3. Nền tảng không chịu trách nhiệm về việc xóa hoặc lưu trữ thất bại thông tin do người dùng đăng khi sử dụng bất kỳ dịch vụ nào của nền tảng. Nền tảng có quyền đánh giá liệu hành vi của người dùng có tuân thủ các quy định trong điều khoản dịch vụ tài khoản nền tảng hay không. Nếu nền tảng tin rằng người dùng vi phạm thỏa thuận này, nền tảng có quyền xóa thông tin được đăng hoặc gửi bởi người dùng cho đến khi dịch vụ bị gián đoạn hoặc chấm dứt.</p>
        <h6>III. Mô tả dịch vụ</h6>
        <p>1. Nền tảng có quyền thay đổi, sửa đổi, thêm hoặc xóa các điều khoản của thỏa thuận dịch vụ này trong tương lai theo quyết định riêng của mình. Tất cả các nội dung sửa đổi đều là một phần của thỏa thuận dịch vụ này. Khi người dùng sử dụng dịch vụ của nền tảng, có nghĩa là người dùng đã chấp nhận việc sửa đổi các điều khoản dịch vụ. Nếu người dùng không đồng ý với việc sửa đổi các điều khoản dịch vụ, có thể chủ động hủy các dịch vụ đã dùng.</p>
        <p>2. Thỏa thuận này và các điều khoản dịch vụ khác của nền tảng tạo thành một thỏa thuận hoàn chỉnh.</p>
        <p>3. Bất kỳ chức năng, dịch vụ và sản phẩm mới được nền tảng thêm vào nhằm mục đích hoàn thiện hoặc tối ưu dịch vụ hiện tại đều được áp dụng các điều khoản thoả thuận này một cách vô điều kiện.</p>
        <p>4. Nếu tài khoản nền tảng không thể lưu trữ hoặc xóa nội dung và thông tin khác của dịch vụ, nền tảng này không chịu bất kỳ trách nhiệm nào. Nền tảng có quyền xóa các tài khoản không được sử dụng trong 3 tháng.</p>
        <p>5. Nếu người dùng lợi dụng dịch vụ để hiển thị hoặc đăng tải nội dung vi phạm pháp luật hoặc xâm phạm bất cứ quyền lợi nào của người khác, dẫn đến việc tố tụng của bên thứ ba hoặc khiến nền tảng bị xử phạt hoặc xét xử, người dùng chấp nhận xoá bỏ ảnh hưởng bất lợi cho nền tảng, bồi thường thiệt hại cho nền tảng và công ty khác, chi nhánh, đại lý, hoặc đối tác và nhân viên bằng hình thức thích hợp, đồng thời giúp họ không chịu tổn thất.</p>
        <p>6. Chấm dứt dịch vụ các trường hợp sau</p>
        <p>6.1 Người dùng đăng thông tin bất hợp pháp, vi phạm nghiêm trọng đạo đức xã hội và các vi phạm khác về các quy định cấm của pháp luật;</p>
        <p>6.2 Khi người dùng sử dụng dịch vụ của nền tảng, nhưng thực hiện không đúng hoặc có hành vi bị cấm theo nội dung thỏa thuận hoặc thông báo của nền tảng;</p>
        <p>6.3 Người dùng cung cấp thông tin đăng ký sai hoặc vi phạm thỏa thuận này, nền tảng có quyền đình chỉ việc cung cấp tất cả hoặc một phần dịch vụ cho người dùng;</p>
        <h6>IV. Điều khoản sử dụng cho trẻ vị thành niên</h6>
        <p>1. Nền tảng này rất coi trọng việc bảo vệ thông tin cá nhân của trẻ vị thành niên. Nếu người dùng là trẻ vị thành niên dưới 18 tuổi, trước khi sử dụng các dịch vụ của nền tảng này, bao gồm điền thông tin cá nhân, vui lòng tăng cường nhận thức bảo vệ cá nhân và hãy thận trọng. Đọc và đồng ý với thỏa thuận này dưới sự giám sát và hướng dẫn của cha mẹ hoặc người giám hộ.</p>
        <p>2. Người dùng vị thành niên hiểu rằng nếu người dùng vi phạm luật pháp và các quy định và nội dung của thỏa thuận này, người dùng và người giám hộ của người dùng sẽ phải chịu mọi hậu quả phát sinh theo quy định của pháp luật.</p>
        <p>3. Lời khuyên đặc biệt cho người dùng vị thành niên</p>
        <p>3.1 Người vị thành niên sử dụng dịch vụ này dưới sự giám sát và hướng dẫn của người giám hộ, học cách sử dụng Internet thích hợp trong thời gian hợp lý, tránh gây nghiện. Người giám hộ và những người khác cung cấp công cụ thanh toán cá nhân cho người dùng vị thành niên phải quản lý chặt chẽ mật khẩu thanh toán của các ngân hàng và các công cụ thanh toán trực tuyến khác. Nếu xảy ra tổn thất do sơ suất, nền tảng không chịu bất kỳ trách nhiệm nào.</p>
        <p>3.2 Người dùng vị thành niên hiểu và đồng ý rằng để bảo vệ trẻ vị thành niên tốt hơn, nền tảng này sẽ áp đặt một số hạn chế nhất định đối với việc chấp nhận và sử dụng dịch vụ của người dùng vị thành niên.</p>
        <p>3.3 Để bảo vệ tốt hơn quyền riêng tư của trẻ vị thành niên, nền tảng nhắc nhở người dùng đăng tải nội dung liên quan đến trẻ em một cách cẩn thận.</p>
        <h6>V. Mô tả phí</h6>
        <p>1. Một số dịch vụ hoặc ứng dụng do nền tảng cung cấp có thể phát sinh chi phí và thanh toán. Việc người dùng sử dụng dịch vụ ứng dụng của nền tảng, nhập số tài khoản và mật khẩu được coi như đã chấp nhận thanh toán. Khi bạn chấp nhận dịch vụ, bạn cần tuân theo điều này. Các tiêu chuẩn trao đổi và thanh toán được nền tảng triển khai trong thời gian thực bao gồm chuyển đổi và thanh toán vật phẩm ảo, mã thông báo và tiền thật. Để nâng cao chất lượng dịch vụ của nền tảng, nền tảng có quyền điều chỉnh và cải thiện các tiêu chuẩn trao đổi và thanh toán. Nếu các tiêu chuẩn trao đổi hoặc thanh toán thay đổi, người dùng nên kiểm tra cẩn thận các dịch vụ. Nếu người dùng tiếp tục sử dụng dịch vụ xem như đã chấp nhận các tiêu chuẩn trao đổi hoặc thanh toán mới.</p>
        <p>2. Dịch vụ thanh toán có thể cần được thực hiện với một quá trình hoàn chỉnh. Nếu dịch vụ bị hủy giữa chừng, nền tảng có quyền không hoàn trả hoặc giải quyết thanh toán.</p>
        <p>3. Các dịch vụ thanh toán mà người dùng được hưởng cũng có thể cần phải thực hiện định kỳ và nhiều lần. Trước khi hết hạn từng dịch vụ, nếu cần hủy dịch vụ, người dùng nên thông báo tới nền tảng. Nếu không dịch vụ sẽ được tự động gia hạn.</p>
        <h6>VI. Quy tắc sử dụng và cấm</h6>
        <p>1. Người dùng nên hiểu bản chất không biên giới của Internet và đặc biệt chú ý tuân thủ tất cả các luật và quy định liên quan của địa phương.</p>
        <p>2. Hành vi bị nghiêm cấm:</p>
        <p>2.1 Hiển thị hoặc đăng tải bất kỳ thông tin không thích hợp gồm vi phạm pháp luật, khiêu dâm, thô tục, đe dọa, quấy rối, vu khống hoặc xúc phạm, phỉ báng, xâm phạm quyền riêng tư của người khác hoặc huỷ hoại danh dự, thiện chí của người khác, vi phạm luật pháp quốc gia, đạo đức xã hội và các quy định khác.</p>
        <p>2.2 Mọi hành vi xâm hại trẻ vị thành niên.</p>
        <p>2.3 Giả vờ hoặc giả mạo bản thân để mọi người lầm tưởng liên quan đến bất kỳ ai hoặc bất kỳ tổ chức nào.</p>
        <p>2.4 Bất cứ mọi hình thức giả mạo nội dung khiến mọi người lầm tưởng được gửi bởi nền tảng.</p>
        <p>2.5 Hiển thị và đăng tải nội dung không được cấp phép.</p>
        <p>2.6 Nội dung xâm phạm bằng sáng chế, nhãn hiệu, bản quyền, bí mật thương mại hoặc các quyền dân sự khác của bất kỳ ai.</p>
        <p>2.7 Gửi thư quảng cáo, tài liệu quảng cáo, thư rác hoặc thông tin sai lệch, v.v.</p>
        <p>2.8 Can thiệp hoặc làm gián đoạn dịch vụ hoặc các máy chủ và mạng được kết nối với dịch vụ, hoặc không tuân thủ các quy định của thỏa thuận này.</p>
        <p>2.9 Vi phạm bất kỳ luật, quy định, quy tắc, quy định liên quan và các quy định ràng buộc pháp lý khác.</p>
        <p>2.10 Đánh cắp mật khẩu, số tài khoản và thông tin kỹ thuật số hoặc tài sản khác.</p>
        <p>2.11 Sử dụng tên của các tổ chức quốc gia hoặc các tổ chức khác.</p>
        <p>2.12 Tuyên truyền phản động, mê tín dị đoan, tục tĩu, khiêu dâm, cờ bạc, bạo lực, giết người, khủng bố, cổ xuý phạm tội, v.v. không tuân thủ các quy định của luật pháp quốc gia và bất kỳ nội dung nào liên quan đến phân biệt chủng tộc, vùng miền, giới tính, phân biệt tôn giáo và tục tĩu.</p>
        <p>2.13 Liên kết đến các trang web khác ngoài nền tảng.</p>
        <p>2.14 Sử dụng các dịch vụ của tài khoản nền tảng hoặc tham gia vào các hoạt động của tài khoản nền tảng thông qua các phương tiện không phù hợp hoặc các phương tiện không công bằng khác. Không can thiệp vào việc cung cấp sản phẩm và dịch vụ thông thường của nền tảng, bao gồm nhưng không giới hạn ở: tấn công, xâm chiếm hoặc làm quá tải máy chủ của nền tảng; tạo, xuất bản, phổ biến, sử dụng bất kỳ hình thức công cụ phụ trợ hoặc chương trình nào ảnh hưởng sự công bằng (Plug-in); sử dụng các lỗ hổng và lỗi chương trình (Bug) để cản trở việc vận hành bình thường của nền tảng hoặc lan truyền các lỗ hổng hoặc lỗi (Bug); can thiệp một cách vô lý hoặc cản trở người khác sử dụng các sản phẩm và dịch vụ do nền tảng cung cấp.</p>
        <p>2.15 Các hành vi khác được cho là không phù hợp bởi nền tảng này.</p>
        <p>2.16 Nền tảng có quyền xem xét nội dung được mô tả, đăng ký sử dụng, đăng và gửi bởi người dùng. Nếu có bất kỳ nội dung nào vi phạm luật pháp và quy định hoặc các quy định có liên quan của thỏa thuận này, nền tảng có quyền xóa hoặc ẩn ngay lập tức mà không cần phải thông báo cho người dùng. Nền tảng sẽ không dung thứ cho nội dung gây khó chịu hoặc hành vi xấu lạm dụng người dùng. Việc nền tảng áp dụng các biện pháp cấm không có nghĩa là từ bỏ quyền truy tố của mình.</p>
        <p>2.17 Các dịch vụ được cung cấp bởi nền tảng này sẽ được cung cấp theo nguyên trạng. Người dùng phải hiểu rõ rằng có thể xuất hiện các lỗ hổng và lỗi (Bug) đã biết và chưa biết trong dịch vụ hoặc do hành vi bị cấm của người dùng khác, và không yêu cầu bất kỳ khoản bồi thường nào từ nền tảng cũng như các chi nhánh.</p>
        <h6>VII. Tiết lộ thông tin và xử lý</h6>
        <p>1. Người dùng chịu trách nhiệm hoàn toàn về nội dung được tải lên, hiển thị hoặc đăng tải trên nền tảng. Trong mọi trường hợp, nền tảng sẽ không chịu trách nhiệm về nội dung được cung cấp bởi bất kỳ người dùng nào, bao gồm nhưng không giới hạn bất kỳ lỗi hoặc thiếu sót nào trong bất kỳ nội dung và bất kỳ dẫn xuất nào. Đối với mất mát hoặc thiệt hại, người dùng có trách nhiệm xử lý và khắc phục tất cả các tranh chấp liên quan đến nội dung họ cung cấp. Nền tảng có quyền từ chối hoặc xóa bất kỳ nội dung nào được cung cấp thông qua dịch vụ này theo luật pháp và quy định cũng như yêu cầu của cơ quan hành chính và tư pháp. Người dùng sử dụng các nội dung trên phải tự chịu rủi ro của mình.</p>
        <p>2. Nền tảng có quyền lưu hoặc tiết lộ nội dung trong các trường hợp sau:</p>
        <p class="list">
            a) Theo yêu cầu của thủ tục pháp lý;
            <br />b) Các điều khoản dịch vụ;
            <br />c) Bên thứ ba bị xâm phạm đưa ra yêu cầu bồi thường;
            <br />d) Để bảo vệ tài khoản nền tảng, quyền của người dùng và an toàn chung, tài sản hoặc an toàn cá nhân;
            <br />e) Các trường hợp khác mà nền tảng thấy cần thiết.
        </p>
        <p>3. Khi người dùng tải lên hoặc hiển thị nội dung hoặc hoạt động trên nền tảng này, được xem như cấp quyền miễn phí và không độc quyền, cho phép sử dụng bản quyền của nội dung trên nền tảng này. Nền tảng này có quyền hiển thị, phổ biến và quảng bá, sao chép, sửa đổi và hiển thị nội dung nêu trên. Bất kỳ tổn thất hoặc lợi nhuận nào từ các hoạt động đăng tải, phổ biến và quảng bá mang lại sẽ do nền tảng thụ hưởng. Nền tảng này có quyền quyết định khen thưởng hoặc khích lệ hay không.</p>
        <p>4. Nếu không có sự cho phép trước của nền tảng hoặc chủ sở hữu, người dùng không được sao chép, bán hoặc sử dụng nội dung được tải lên hoặc hiển thị bởi người khác với mục đích thương mại.</p>
        <p>5. Quy tắc xử lý tài khoản nền tảng</p>
        <p>5.1 Họ tên, tài khoản, biệt danh có từ ngữ vi phạm pháp luật, không văn minh, không tuân thủ các quy định quốc gia.Tùy thuộc vào mức độ nghiêm trọng của các trường hợp, nền tảng sẽ đưa ra hình phạt khoá tài khoản trong thời gian nhất định; nếu tình tiết nghiêm trọng, sẽ bị phạt khoá vĩnh viễn.</p>
        <p>5.2 Liên quan đến xâm nhập, đánh chặn, phá hủy, sao chép, sửa đổi chương trình và quảng cáo, bán và sử dụng các chương trình phụ trợ khác nhau hoặc các chương trình bất hợp pháp độc hại, nghĩa là sử dụng trình cấm hoặc quảng cáo trình cấm trong dịch vụ. Tùy thuộc vào mức độ nghiêm trọng của các trường hợp, nền tảng sẽ đưa ra hình phạt khoá tài khoản trong thời gian nhất định; nếu tình tiết nghiêm trọng, sẽ bị phạt khoá vĩnh viễn.</p>
        <p>5.3 Lừa đảo hoặc lừa dối người dùng khác dưới bất kỳ hình thức giả mạo nào, chẳng hạn như đăng tải trang web giả hoặc virus, tin nhắn giả mạo, quảng cáo bất hợp pháp, mã độc, trojan, plugin, virus, thông tin khiêu dâm, quảng cáo spam và thông tin khác. Tùy thuộc vào mức độ nghiêm trọng của các trường hợp, nền tảng sẽ đưa ra hình phạt khoá tài khoản trong thời gian nhất định; nếu tình tiết nghiêm trọng, sẽ bị phạt khoá vĩnh viễn.</p>
        <p>5.4 Đăng tải trang web bất hợp pháp thông qua tài khoản nền tảng để quảng cáo hoặc sử dụng mã độc, trojan, plugin, vi rút, thông tin khiêu dâm, quảng cáo spam, quảng cáo bất hợp pháp và thông tin khác. Tùy thuộc vào mức độ nghiêm trọng của các trường hợp, nền tảng sẽ đưa ra hình phạt khoá tài khoản trong thời gian nhất định; nếu tình tiết nghiêm trọng, sẽ bị phạt khoá vĩnh viễn.</p>
        <p>5.5 Đăng tải từ ngữ vi phạm luật pháp và quy định của chính phủ như kích động bạo lực, phản động, tục tĩu, bạo lực, phân biệt chủng tộc, phân biệt tôn giáo, phân biệt vùng miền v.v. thông qua tài khoản nền tảng, bao gồm cả việc viết ngược hoặc mã hoá các từ liên quan đó. Tùy thuộc vào mức độ nghiêm trọng của hành vi, sẽ bị phạt khoá tài khoản trong một khoảng thời gian giới hạn; nếu tình tiết nghiêm trọng, sẽ bị phạt khoá vĩnh viễn và báo cáo cho các cơ quan có thẩm quyền để truy tố trước pháp luật.</p>
        <p>5.6 Gây ra hoặc bán lỗi hệ thống, tấn công hoạt động của máy chủ, chiếm đoạt lợi ích cá nhân, gây ảnh hưởng đến sự công bằng và hoạt động bình thường của người chơi khác. Sau khi kiểm tra và xác minh, tài khoản sẽ bị khoá và tất cả các nội dung bất hợp pháp sẽ bị xóa. Tùy thuộc vào mức độ nghiêm trọng của hành vi, sẽ bị phạt khoá tài khoản trong một khoảng thời gian giới hạn; nếu tình tiết nghiêm trọng, sẽ bị phạt khoá vĩnh viễn.</p>
        <p>5.7 Ăn cắp hoặc tham gia đánh cắp tài khoản của người khác, gây thiệt hại nghiêm trọng cho người bị đánh cắp. Sau khi kiểm tra và xác minh, tùy thuộc vào mức độ nghiêm trọng của hành vi, sẽ bị phạt khoá tài khoản trong một khoảng thời gian giới hạn; nếu tình tiết nghiêm trọng, sẽ bị phạt khoá vĩnh viễn và báo cáo cho các cơ quan có thẩm quyền để truy tố trước pháp luật.</p>
        <p>5.8 Xúc phạm, vu khống, tục tĩu, đe dọa, lăng mạ người dùng khác, xuyên tạc sự thật, lan truyền tin đồn sai lệch, ảnh hưởng xấu đến môi trường dịch vụ, v.v. Tùy thuộc vào mức độ nghiêm trọng của các trường hợp, nền tảng sẽ đưa ra hình phạt khoá tài khoản trong thời gian nhất định; nếu tình tiết nghiêm trọng, sẽ bị phạt khoá vĩnh viễn.</p>
        <h6>VIII. Về quyền và miễn trừ trách nhiệm của nền tảng</h6>
        <p>1. Ngoài các điều khoản dịch vụ / thỏa thuận hiện có, nền tảng được hưởng các quyền sở hữu trí tuệ sau:</p>
        <p>1.1 Nền tảng có quyền tương ứng với dịch vụ, phần mềm, chương trình và dữ liệu được bảo vệ bởi luật sở hữu trí tuệ hoặc luật khác được sử dụng trong dịch vụ này.</p>
        <p>1.2 Nội dung được truyền tải qua dịch vụ được bảo vệ bởi luật bản quyền, luật thương hiệu, luật sáng chế hoặc luật khác, nếu không có sự cho phép rõ ràng của nền tảng, người dùng sẽ không được sửa đổi, thuê, phân phối hoặc tạo ra các tác phẩm khác. Ngoại trừ nội dung được đăng trên nền tảng.</p>
        <p>1.3 Người dùng có quyền sử dụng không độc quyền phần mềm được dùng trong dịch vụ này, nhưng không được phép hoặc cho phép bất kỳ bên thứ ba nào sao chép, sửa đổi, bán hoặc lấy sản phẩm.</p>
        <p>1.4 Tài khoản, hình ảnh, tên sản phẩm và dịch vụ đều được sở hữu bởi nền tảng và các chi nhánh. Không ai có thể sử dụng, sao chép hoặc dùng cho các mục đích khác mà không có sự cho phép trước bằng văn bản của nền tảng.</p>
        <p>2. Nền tảng không đảm bảo tính chính xác hoặc độ tin cậy của bất kỳ nội dung, thông tin hoặc quảng cáo nào được người dùng đăng tải từ bất kỳ kênh nào liên quan đến dịch vụ. Nền tảng không chịu trách nhiệm đối với bất kỳ quảng cáo, sản phẩm, thông tin hoặc tư liệu do người dùng đăng tải. Người dùng phải chú ý phòng ngừa và tự chịu rủi ro.</p>
        <p>3. Nền tảng có quyền cải thiện hoặc sửa chữa bất kỳ thiếu sót hoặc lỗi nào trong bất kỳ phần nào của dịch vụ.</p>
        <p>4. Nền tảng không đảm bảo các vấn đề sau (bao gồm nhưng không giới hạn):</p>
        <p class="list">
            a) Dịch vụ này phù hợp với yêu cầu sử dụng của tất cả người dùng;
            <br />b) Dịch vụ này không bị xáo trộn, kịp thời, an toàn, đáng tin cậy hoặc không có lỗi;
            <br />c) Bất kỳ sản phẩm, dịch vụ hoặc tài liệu nào khác mà người dùng nhận được từ nền tảng đều đáp ứng mong đợi của người dùng;
        </p>
        <p>5. Người dùng tự chịu trách nhiệm về bất kỳ thông tin nào được tải xuống hoặc có được thông qua dịch vụ này, người dùng phải chịu trách nhiệm hoàn toàn về thiệt hại của điện thoại di động hoặc hệ thống thiết bị khác hoặc mất dữ liệu do sử dụng;</p>
        <p>6. Nền tảng không chịu bất kỳ khoản bồi thường trực tiếp, gián tiếp, ngẫu nhiên phát sinh hoặc xử phạt nào nếu xảy ra mất thông tin hoặc tổn thất hữu hình, vô hình đối với lợi nhuận, uy tín vì những lý do sau:</p>
        <p class="list">
            a) Dịch vụ sử dụng được hoặc không được;
            <br />b) Bất kỳ sản phẩm, tài liệu hoặc dịch vụ được mua hoặc nhận được thông qua dịch vụ này;
            <br />c) Sử dụng trái phép hoặc sửa đổi thông tin người dùng;
            <br />d) Thông tin người dùng bị mất hoặc bị xóa;
            <br />e) Các vấn đề khác liên quan đến dịch vụ này.
        </p>
        <p>7. Khi duyệt Internet, người dùng có thể xác định thư mục tìm kiếm bằng tài khoản nền tảng. Thư mục truy xuất có thể dẫn người dùng đến các trang web bị xem là tấn công hoặc không phù hợp. Nền tảng không thể xem nội dung của các trang web được liệt kê trong thư mục truy xuất. Do đó, nền tảng không chịu trách nhiệm về tính chính xác, hợp pháp và chính đáng của nó.</p>
        <p>8. Nền tảng này được bảo vệ và ràng buộc bởi các luật và quy định có liên quan về quyền sở hữu trí tuệ và các quy định bảo vệ. Nội dung được truyền tải, đăng tải và hiển thị trên nền tảng này thuộc về tác giả / chủ sở hữu ban đầu. Nếu không có sự đồng ý của tác giả / chủ sở hữu ban đầu, người dùng sẽ không được sao chép, sửa đổi, điều chỉnh, dịch, biên dịch, tải lên và đăng tải hoặc dùng với mục đích thương mại toàn bộ hoặc một phần nội dung. Nếu tác giả / chủ sở hữu nội dung không muốn đăng tải nội dung trên nền tảng, vui lòng thông báo cho nền tảng này để xóa hoặc hạn chế đăng tải kịp thời.</p>
        <p>9. Dựa trên sự tuân thủ nghiêm ngặt của người dùng với tuyên bố từ chối trách nhiệm này, nền tảng cung cấp cho người dùng các dịch vụ như tải lên, kênh đăng tải và lưu trữ thông tin. Nền tảng không thực hiện bất kỳ sửa đổi hoặc chỉnh sửa nào đối với nội dung được đăng bởi người dùng. Người dùng phải thận trọng và chịu trách nhiệm về nội dung đã đăng tải. Nền tảng không đảm bảo tính an toàn của nội dung được đăng bởi người dùng, người dùng nên tự giữ bản gốc. Nền tảng sẽ không chịu trách nhiệm nếu bất kỳ nội dung tải lên nào bị mất vì bất cứ lý do gì.</p>
        <p>10. Nội dung của nền tảng không đại diện cho quan điểm của nền tảng, nó chỉ mang tính tham khảo cho sự giao tiếp giữa người dùng và không có nghĩa là nền tảng đưa ra bất kỳ hướng dẫn và đề xuất nào cho người dùng đối với mọi hành vi. Vì vậy, bất kỳ tranh cãi nào cũng không liên quan gì đến nền tảng. Các liên kết hoặc nội dung định hướng khác không được đăng bởi nền tảng tức không phải là tài nguyên do nền tảng kiểm soát. Nền tảng không đảm bảo tính xác thực, tính hợp pháp, tính toàn vẹn và bảo mật của nó. Nền tảng không chịu bất kỳ trách nhiệm nào đối với các tổn thất do nội dung gây ra.</p>
        <p>11. Nội dung được đăng tải trên nền tảng này là để hiển thị và giao tiếp với người dùng khác. Lưu trữ trái phép, in lại hoặc sử dụng với mục đích thương mại có thể vi phạm các quyền hợp pháp của người khác.</p>
        <p>12. Nền tảng có thể phải chịu các trục trặc bất khả kháng như gián đoạn tạm thời, chậm trễ, thiếu sót, v.v. do các cuộc tấn công của hacker, virus máy tính, quy định của chính phủ, lỗi phần mềm và thiết bị phần cứng, lỗi Internet trong lĩnh vực viễn thông hoặc các trang web khác được liên kết với nền tảng này. Nền tảng không chịu bất kỳ trách nhiệm nào về việc rò rỉ, mất mát, chiếm dụng hoặc giả mạo dữ liệu.</p>
        <p>13. Nền tảng có quyền sử dụng nội dung được tải lên bởi người dùng hoặc người dùng khác cho mục đích quảng bá nền tảng mà không phải trả bất kỳ khoản phí nào hoặc chịu bất kỳ trách nhiệm nào đối với người dùng. Nền tảng có quyền đánh dấu logo của nền tảng khi quảng bá nội dung được đăng bởi người dùng.</p>
        <p>14. Người dùng phải bảo quản thông tin cá nhân liên quan đến việc sử dụng nền tảng này. Nếu người dùng cung cấp thông tin cho người khác sử dụng, v.v., dẫn đến thông tin bị tiết lộ, người dùng phải chịu trách nhiệm.</p>
        <h6>IX. Thông báo và quyền tài phán</h6>
        <p>1. Các thông báo do nền tảng gửi cho người dùng có thể ở dạng email, thông báo trang, thư thông thường, cuộc gọi điện thoại hoặc những gì nền tảng cho là phù hợp. Khi các điều khoản dịch vụ được sửa đổi hoặc các vấn đề khác được thay đổi, nền tảng sẽ được thông báo theo hình thức nêu trên.</p>
        <p>2. Hiệu lực, hiệu suất, giải thích và giải quyết tranh chấp của các Điều khoản dịch vụ này đều được áp dụng theo luật của nhà nước Cộng hòa Xã hội chủ nghĩa Việt Nam. Nếu người dùng có tranh chấp với nền tảng khởi nguồn từ việc sử dụng nền tảng hoặc do việc thực thi thỏa thuận này, hãy đưa tranh chấp ra toà án để phán xử.</p>
        <p>3. Nếu một điều khoản trong thỏa thuận dịch vụ này không hợp lệ do mâu thuẫn với luật pháp hiện hành của nhà nước Cộng hòa Xã hội chủ nghĩa Việt Nam, những nội dung khác của thoả thuận đều không bị ảnh hưởng.</p>
        <h6>10. Thông tin liên lạc</h6>
        <p>Nếu tác giả phát hiện nội dung được đăng hoặc hiển thị bởi người dùng vi phạm quyền và lợi ích hợp pháp của người dùng khác hoặc chủ sở hữu, vui lòng gửi ngay thông báo vi phạm bản quyền tới nền tảng và gửi chứng nhận quyền sở hữu, liên kết cụ thể và bằng chứng vi phạm chi tiết tới [business@17sing.tw] , chúng tôi sẽ hết lòng phối hợp giải quyết.</p>
    </div>
</template>

<style lang="scss">
.pageAgreement {
    color: #666;
    background: #fff;
    padding: $page-padding;
    line-height: 1.4em;
    h5,
    h6 {
        color: $text-black;
        font-weight: bold;
    }
    h5 {
        text-align: center;
        font-size: 110%;
        padding: 0.1rem 0 0.2rem 0;
    }
    h6 {
        font-size: 90%;
        padding: 0.1rem 0;
    }
    p {
        font-size: 90%;
        padding: 0.1rem 0;
        text-indent: 2em;
        &.list {
            text-indent: 0;
            padding-left: 2em;
        }
    }
}
</style>