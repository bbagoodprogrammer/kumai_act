export default {
    //html/index.html
    title: '簽約',

    //html/app_share.ejs
    share_title: '簽約',
    share_desc: '成爲簽約用戶，即可對歡鑽收益進行提款，且簽約等級越高，提款比例越高。',
}