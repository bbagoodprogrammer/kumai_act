<template>
  <div class="page pageIndex">
    <div id="main">
      <div class="container">
      </div>
    </div>
    <!-- <div class="loading">
      <img src="./img/loading.gif" alt="">
    </div> -->
    <div class="promptBox">
      <p></p>
      <div class="ok">
        <a href="javascript:;"></a>
      </div>
    </div>
    <div class="mask" style="display: none"></div>
    <!-- <textarea id="anno_jst" style="display:none;"> -->
    <div id="main1" v-if="count > 0">
      <div v-for="(item,index) in noticesSetTime" :key="index">
        <div v-if="item.cover_img == ''">
          <div class="section">
            <p class="time">{{item.active_time}}</p>
            <div class="con clearfix">
              <div class="logo">
                <img src="" alt="">
              </div>
              <div class="description">
                <p class="title">{{item.title}}</p>
                <pre class="pre1">
						{{item.content}}
				</pre>
              </div>
            </div>
          </div>
        </div>
        <div v-else>
          <div class="section_img">
            <p class="time">{{item.active_time}}</p>
            <div class="con">
              <a :href="item.url" class="banner">
                <img :src="notice.cover_img" alt="">
              </a>
              <div class="des">
                <div class="title title_one">{{item.title}}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
    <p class="no_notice no" v-else></p>
  </div>
</template>

<script>

import { mapState } from "vuex"
export default {
  computed: {
    ...mapState(['notices', 'count']),
    noticesSetTime () {
      let arr = this.notices
      for (var i = 0; i < arr.length; ++i) {
        var ts = arr[i]['active_time'];
        arr[i]['active_time'] = this.getLocalTime(ts);
      }
      return arr
    }
  },
  methods: {
    getLocalTime (t) {
      var time = new Date(parseInt(t) * 1000);
      var year = time.getFullYear();
      var month = time.getMonth() + 1;
      var date = time.getDate();
      var hour = time.getHours();
      var minute = time.getMinutes();
      month = month < 10 ? '0' + month : month;
      date = date < 10 ? '0' + date : date;
      hour = hour < 10 ? '0' + hour : hour;
      minute = minute < 10 ? '0' + minute : minute;
      return year + "-" + month + "-" + date + " " + hour + ":" + minute;
    }
  }

}
</script>

<style lang="scss">
.pageIndex {
  * {
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    color: #333;
    font-family: PingFangSC-Regular;
  }
  @function rem($px) {
    @return $px/40 + rem;
  }
  body {
    font-size: 0.7rem;
    background: #f0f0f0;
    background-size: cover;
  }
  .fl {
    float: left;
  }
  .fr {
    float: right;
  }
  img {
    width: 100%;
  }
  $color: #7326ff;
  @mixin flex($jc, $ai) {
    display: -webkit-flex;
    display: flex;
    -webkit-flex-flow: row nowrap;
    flex-flow: row nowrap;
    -webkit-justify-content: $jc;
    justify-content: $jc;
    -webkit-align-items: $ai;
    align-items: $ai;
  }
  #main {
    .container {
      padding: 1rem 0;
      .section {
        margin-bottom: rem(20);
        .time {
          color: #878787;
          font-size: rem(24);
          text-align: center;
          padding: 0 0 rem(20) 0;
          line-height: 1;
        }
        .con {
          padding: 0 1.2rem 0 0.75rem;
          .logo {
            width: rem(90);
            height: rem(90);
            float: left;
            margin-top: -1rem;
          }
          .description {
            width: rem(551);
            //height: rem(406);
            background: #fff;
            border-radius: 0px rem(34) rem(34) rem(34);
            float: left;
            margin-left: rem(20);
            .title {
              color: #878787;
              font-size: rem(26);
              padding: rem(18) 0;
              border-bottom: 0.01rem solid #ccc;
              padding-left: rem(30);
              padding-right: rem(30);
            }
            .pre1 {
              padding: rem(27) rem(30) rem(30) rem(30);
              white-space: pre-line;
              line-height: 1rem;
              font-family: PingFangSC-Regular;
              color: #000;
              font-size: rem(32);
            }
          }
        }
      }
      .section_img {
        width: rem(650);
        margin: 0 auto rem(65);
        .time {
          color: #878787;
          font-size: rem(24);
          text-align: center;
          padding: 0 0 0.8rem 0;
        }
        .con {
          border-radius: rem(34);
          background: #fff;
          .banner {
            display: block;
            width: rem(650);
            height: rem(340);
            border-radius: rem(34) rem(34) 0px 0px;
            img {
              width: 100%;
              height: 100%;
              border-radius: rem(34) rem(34) 0px 0px;
            }
          }
          .des {
            .title {
              font-size: rem(32);
              color: #000;
              font-family: PingFangSC-Regular;
              padding: rem(29) rem(0) rem(16) rem(31);
            }
            .title_one {
              padding: rem(29) rem(31) rem(27) rem(31);
            }
            .pre2 {
              font-size: rem(26);
              color: #878787;
              padding: rem(0) rem(36) rem(30) rem(30);
            }
          }
        }
      }
      .no_notice {
        padding: 1rem;
        text-align: center;
        font-size: 1rem;
      }
    }
  }
  .promptBox {
    display: none;
    position: fixed;
    left: 50%;
    top: 35%;
    background-color: #2e3846;
    text-align: center;
    border-radius: 0.5rem;
    margin-left: -8rem;
    z-index: 100;
    font-size: 1rem;
    color: #000;
    width: 16rem;
    box-shadow: 0 2px 4px 0 rgba(0, 0, 0, 0.3);
    p {
      font-size: 14px;
      color: #fff;
      padding: 10px 30px 5px;
    }
    .ok {
      white-space: nowrap;
      padding: 10px 30px;
      text-align: center;
      a {
        display: inline-block;
        width: auto;
        min-width: 90px;
        margin-left: 0px;
        margin-top: 2px;
        outline: none;
        background-color: #795aac;
        color: #fff;
        text-decoration: none;
        padding: 4px 12px;
        border-radius: 4px;
        font-size: 14px;
      }
    }
  }
  .maskBox {
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    display: none;
    .buy {
      display: none;
      position: fixed;
      left: 50%;
      bottom: 50%;
      z-index: 99;
      overflow: hidden;
      width: rem(480);
      height: rem(222);
      background: rgba(255, 255, 255, 1);
      border-radius: rem(22);
      margin-top: -30%;
      margin-left: rem(-240);
      p {
        padding: 1.35rem 0 1rem;
        font-size: rem(30);
        border-bottom: 1px solid #d9d9d9;
        text-align: center;
      }
      a {
        float: left;
        width: 49.5%;
        padding: 0.6rem 0;
        font-size: rem(26);
        text-align: center;
      }
      .leftBtn {
        color: #878787;
      }
      .rightBtn {
        color: #68ACFF;
        border-left: 1px solid #d9d9d9;
      }
    }
    .buy_success,
    .unpay {
      display: none;
      position: fixed;
      left: 50%;
      bottom: 50%;
      z-index: 99;
      overflow: hidden;
      width: rem(440);
      height: rem(222);
      background: rgba(255, 255, 255, 1);
      border-radius: rem(22);
      margin-top: -30%;
      margin-left: rem(-220);
      p {
        padding: 1.35rem 0 1rem;
        font-size: rem(30);
        border-bottom: 1px solid #d9d9d9;
        text-align: center;
      }
      a {
        float: left;
        width: 100%;
        padding: 0.6rem 0;
        font-size: rem(26);
        text-align: center;
        color: #68ACFF;
      }
    }
  }

  .bottom {
    position: fixed;
    bottom: 0;
    height: rem(98);
    line-height: rem(98);
    border-top: 1px solid #f0f0f0;
    width: 100%;
    padding: 0 1rem;
    a {
      display: block;
      width: rem(150);
      height: rem(58);
      line-height: rem(58);
      background: rgba(255, 102, 105, 1);
      border-radius: rem(29);
      float: right;
      text-align: center;
      font-size: rem(26);
      color: #fff;
      margin-top: rem(17);
    }
  }
  .loading {
    position: fixed;
    left: 0;
    top: 0;
    height: 100%;
    width: 100%;
    background-color: #000;
    opacity: 0.4;
    z-index: 0;
    text-align: center;
    display: none;
    img {
      width: 1.75rem;
      height: 0.95rem;
      margin-top: 15rem;
    }
  }
}
</style>