export default {
    //html/index.html
    title: 'Sign with us',

    //html/app_share.ejs
    share_title: 'Sign with us',
    share_desc: '',
}