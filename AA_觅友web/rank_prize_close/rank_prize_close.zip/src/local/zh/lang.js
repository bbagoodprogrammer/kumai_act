export default {
    //html/index.html
    title: "上期獎勵",
    prizeTips:
        "上期親密週榜前三的用戶，均可在下週日凌晨0點開始獲得對應的榜單獎勵",
    tips_title1: "榜单奖励",
    tips_title2: "上期獲得者",
    disparityTips: "距離上一位親密值",
    topNums: {
        1: "第一名",
        2: "第二名",
        3: "第三名"
    },
    examineIng: "审核中",
    examine_tips: "請留意系統通知的認知結果",
    days: "天"
};
