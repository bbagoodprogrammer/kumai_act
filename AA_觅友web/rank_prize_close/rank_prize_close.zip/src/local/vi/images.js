export default {
    banner: require('./img/banner.png'),
}