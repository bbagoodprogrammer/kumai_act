export default {
    //html/index.html
    title: "Quà kỳ trước",
    prizeTips:
        "Người chơi top 3 thân mật tuần, sẽ nhận quà xếp hạng vào 0h chủ nhật tuần tiếp theo",
    tips_title1: "Quà xếp hạng",
    tips_title2: "Người nhận kỳ trước",
    disparityTips: "Điểm thân mật cần",
    topNums: {
        1: "Hạng 1",
        2: "Hạng 2",
        3: "Hạng 3"
    },
    examineIng: "Đang duyệt",
    examine_tips: "Vui lòng để ý kết quả thông báo",
    days: "ngày"
};
