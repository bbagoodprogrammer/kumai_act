export default {
    //html/index.html
    title: 'توقيع',

    //html/app_share.ejs
    share_title: 'توقيع',
    share_desc: '',
}