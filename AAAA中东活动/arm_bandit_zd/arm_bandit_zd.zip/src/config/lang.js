const vietnamLang = {
    superbandit: "سوبر فتحة  الآلة", //超級老虎機
    triple_prize: "كسب ثلاث مرات الجوائز باستمرار",  //3倍獎勵抽不停
    activity_time: "1.27 12:00-2.3 23:00",  // 活动时间
    activity_rules: "القواعد", //活动规则》》
    draw_record: "تفاصيل",  //抽獎記錄>>
    my_knapsack: "حقيبتي",  //我的背包
}
export default vietnamLang