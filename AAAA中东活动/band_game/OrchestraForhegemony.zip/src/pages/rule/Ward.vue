<template>
  <div class="ward">
    <div class="activeTime">
      <p>وقت النشاط</p>
      <p>12:00 في يوم26 من نوفمبر إلي23:00 في يوم 2 من ديسمبر بتوقيت دبي</p>
    </div>
    <h5>الجوائز</h5>
    <div class="wardBox">
      <h6>قائمة غرفة الغناء </h6>
      <p>صاحب الغرفة الأولي : سيارة الدخول الرائع(14 يوم)</p>
      <p>صاحب الغرفة الثانية : سيارة الدخول الرائع(14 يوم)</p>
      <p>صاحب الغرفة الثالثة : سيارة الدخول الرائع(14 يوم)</p>
    </div>
    <div class="gongx">
      <h5>قائمة المساهمة </h5>
      <h6>المركز الاول</h6>
      <p>شارة غرفة الغناء (30 يومًا) + هدية مايك الذهب للحقيبة 50 * (20 عملة ذهبية) + 2000 عملة ذهبية + 2000 فول ذهبي</p>
      <h6>المركز الثاني</h6>
      <p>شارة غرفة الغناء (30 يومًا) + هدية مايك الذهب للحقيبة 30 * (20 عملة ذهبية) + 1500 عملة ذهبية + 1500 فول ذهبي</p>
      <h6>المركز الثالث</h6>
      <p>شارة غرفة الغناء (30 يومًا) + هدية مايك الذهب للحقيبة 20 * (20 عملة ذهبية) + 1000 عملة ذهبية + 1000 فول ذهبي</p>
      <h6>المركز 4-10</h6>
      <p>شارة غرفة الغناء (30 يومًا) + هدية مايك الذهب للحقيبة 8 * (20 عملة ذهبية) + 500 عملة ذهبية + 500 فول ذهبي</p>
      <p> ملاحظة: سوف تُعطَى هذه الجوائز أثناء خمسة الأيام بعد انتهاء النشاط</p>
    </div>
    <p class="tips">التفسير النهائي لهذا النشاط ينتمي إلى منظم الحدث</p>
  </div>
</template>
<script>
export default {

}
</script>
<style lang="scss" scoped>
.activeTime {
  text-align: center;
  margin-top: 0.47rem;
}
h5 {
  font-size: 140%;
  color: #ffdb5e;
  text-align: center;
  margin-top: 0.37rem;
}
.wardBox {
  padding: 0 0.24rem;
  h6 {
    font-size: 110%;
    color: #ffdb5e;
  }
  p {
    color: #e8ceff;
  }
}
.gongx {
  padding: 0 0.24rem;
  margin-top: 0.39rem;
  h5 {
    font-size: 110%;
    color: #ffdb5e;
    text-align: right;
  }
  h6 {
    color: #c9ffe2;
  }
  p {
    color: #e8ceff;
  }
}
.tips {
  padding: 0 0.24rem;
  text-align: center;
  color: #646dff;
  font-size: 120%;
  margin-top: 2rem;
}
</style>
