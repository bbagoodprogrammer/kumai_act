export default {
    //html/index.html
    title: 'Menandatangani kontrak',
}