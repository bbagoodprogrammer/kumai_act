<template>
  <div class="wards">
    <p class="activeTime">Thời gian:18h 25/1 – 21h 4/2</p>
    <h5><i class="titleLeft"></i>Thưởng top 10 BXH Bài hát<i class="titleRight"></i></h5>
    <div class="wardTop">
      <h5>Hạng nhất:</h5>
      <p>Huy chương Vua Quà Tặng (30 ngày) + ID đẹp 8 số + Xe GTR (30 ngày) + Túi quà bài hát Siêu Xe giới hạn (1388 xu) + 3000 xu + 3000 đậu</p>
      <h5>Hạng nhì:</h5>
      <p>Huy chương Vua Quà Tặng (30 ngày) + Xe GTR (30 ngày) + Túi quà bài hát Siêu Xe giới hạn (1388 xu) + 2000 xu + 2000 đậu</p>
      <h5>Hạng ba:</h5>
      <p>Huy chương Vua Quà Tặng (30 ngày) + Xe GTR (30 ngày) + Túi quà bài hát Siêu Xe giới hạn (1388 xu) + 1500 xu + 1500 đậu</p>
      <h5>Hạng 4-5:</h5>
      <p>Huy chương Vua Quà Tặng (30 ngày) + Xe GTR (30 ngày) + Túi quà bài hát Siêu Xe giới hạn (1388 xu) + 1000 xu + 1000 đậu</p>
      <h5>Hạng 6-10:</h5>
      <p>Xe GTR (30 ngày) + Túi quà bài hát Siêu Xe giới hạn (1388 xu) + 800 xu + 800 đậu</p>
    </div>
    <h5><i class="titleLeft"></i>Thưởng top 10 BXH Phòng Kara<i class="titleRight"></i></h5>
    <div class="kRoomTop">
      <h5>Hạng nhất: </h5>
      <p>Huy chương Vua Quà Tặng (30 ngày) + ID đẹp 8 số + Xe GTR (30 ngày) + Túi quà bài hát Siêu Xe giới hạn (1388 xu) + 3000 xu + 3000 đậu</p>
      <h5>Hạng nhì:</h5>
      <p>Huy chương Vua Quà Tặng (30 ngày) + Xe GTR (30 ngày) + Túi quà bài hát Siêu Xe giới hạn (1388 xu) + 2000 xu + 2000 đậu</p>
      <h5>Hạng ba:</h5>
      <p>Huy chương Vua Quà Tặng (30 ngày) + Xe GTR (30 ngày) + Túi quà bài hát Siêu Xe giới hạn (1388 xu) + 1500 xu + 1500 đậu</p>
      <h5>Hạng 4-5:</h5>
      <p>Huy chương Vua Quà Tặng (30 ngày) + Xe GTR (30 ngày) + Túi quà bài hát Siêu Xe giới hạn (1388 xu) + 1000 xu + 1000 đậu</p>
      <h5>Hạng 6-10:</h5>
      <p>Xe GTR (30 ngày) + Túi quà bài hát Siêu Xe giới hạn (1388 xu) + 800 xu + 800 đậu</p>
    </div>
    <h5><i class="titleLeft"></i> Top 10 BXH Nổi Tiếng<i class="titleRight"></i></h5>
    <div class="peopleTop">
      <h5>Top 1:</h5>
      <p>Huy chương Vua Nổi Tiếng (30 ngày) + 1500 xu + 1500 đậu</p>
      <h5>Top 2:</h5>
      <p>Huy chương Vua Nổi Tiếng (30 ngày) + 1000 xu + 1000 đậu</p>
      <h5>Top 3:</h5>
      <p>Huy chương Vua Nổi Tiếng (30 ngày) + 800 xu + 800 đậu</p>
      <h5>Top 4-5:</h5>
      <p>Huy chương Vua Nổi Tiếng (30 ngày) + 600 xu + 600 đậu</p>
      <h5>Top 6-10:</h5>
      <p>300 xu + 600 đậu</p>
    </div>

    <h5><i class="titleLeft"></i> Thưởng hoàn trả xu<i class="titleRight"></i></h5>
    <div class="fanhuan">
      <p>1. Tặng bài hát dự thi Đốt Pháo (5 xu), Lì Xi Tết (20 xu), Dư Dả Cả Năm (199 xu) sẽ được hoàn trả lại 5% số xu vào sáng sớm hôm sau. Ví dụ tặng 1 Dư Dả Cả Năm 199 xu, hôm sau sẽ được hoàn trả 10 xu.</p>
      <p>2. Tặng thí sinh dự thi tại phòng Kara sau khi báo danh Pháo Tết (5 xu), Túi May Mắn (20 xu), Múa Lân (199 xu) sẽ được hoàn trả lại 5% số xu vào sáng sớm hôm sau. Ví dụ tặng 1 Múa Lân 199 xu, hôm sau sẽ được hoàn trả 10 xu.</p>
    </div>

    <h5><i class="titleLeft"></i> Quy định phần thưởng<i class="titleRight"></i></h5>
    <div class="tips">
      <p>1. Phần thưởng ID đẹp 8 số, ban tổ chức sẽ liên hệ bạn để cung cấp danh sách ID có thể nhận, bạn cần phải cung cấp số điện thoại chưa đăng ký để liên kết với ID.</p>
      <p>2. Túi quà nhận từ sự kiện có thể vào Tôi – Túi để xem, khi tặng quà có thể chọn tặng quà từ Túi. iOS cần cập nhật phiên bản NowKara mới nhất để sử dụng.</p>
    </div>

    <p class="btnMsg">Quyết định của ban tổ chức là quyết định cuối cùng</p>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.wards {
  .activeTime {
    color: #faefc9;
    text-align: center;
    font-weight: 0.24rem;
    font-weight: 600;
    margin-top: 0.38rem;
  }

  > h5 {
    text-align: center;
    color: #ffe58a;
    margin: 0.46rem auto 0.18rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: space-between;
    width: 5.9rem;
    .titleLeft {
      width: 1.23rem;
      height: 0.33rem;
      background: url(../../assets/img/titleLeft.png);
      background-size: 100% 100%;
      margin-right: 0.11rem;
    }
    .titleRight {
      width: 1.23rem;
      height: 0.33rem;
      background: url(../../assets/img/titleRight.png);
      background-size: 100% 100%;
      margin-left: 0.11rem;
    }
  }
  .wardTop {
    > h5 {
      color: #ffebc5;
      font-size: 0.21rem;
      margin-top: 0.2rem;
      font-weight: 600;
    }
  }
  .kRoomTop {
    > h5 {
      color: #ffebc5;
      font-size: 0.21rem;
      margin-top: 0.2rem;
      font-weight: 600;
    }
  }
  .fanhuan,
  .tips {
    p {
      margin-top: 0.22rem;
    }
  }
  .peopleTop {
    > h5 {
      color: #ffebc5;
      font-size: 0.21rem;
      margin-top: 0.2rem;
      font-weight: 600;
    }
  }
  p {
    color: #ffebc5;
    font-weight: 600;
    font-size: 0.22rem;
    line-height: 0.36rem;
  }

  .btnMsg {
    margin-top: 1.2rem;
    text-align: center;
    font-size: 0.24rem;
    font-weight: 600;
    color: #ffebc5;
  }
}
</style>
