﻿export default {
    title: '王者挑戰賽',

    rank: '排名',
    not_reg: '尚未報名',
    not_in_rank: '未晋级',
    not_mic_user: '無人上麥\n快去演唱吧',
    boy: '男神賽道',
    girl: '女神賽道',
}