# 魅力星耀赛活动条网页

## 接口文档
   * [接口文档]()

## 蓝湖设计图
   * [蓝湖设计图](https://lanhuapp.com/web/#/item/project/board?pid=91742a41-6d1e-4dca-af9f-5247a3de646e)

## 服务器目录
   * /home/17sing/web/activity.17sing.tw/html/static_html/2019/attractiveStar/button/
