<template>
  <div class="wards">
    <p class="activeTime">Waktu Acara:Pukul 18:00:00 tgl 15 Nov - pukul 21:00:00 tgl 25 Nov </p>
    <h5>Hadiah untuk Top 10 dari Top Hegemon Nyanyian:</h5>
    <div class="wardTop">
      <h5>Top 1:</h5>
      <p>Lencana Gift King (31 hari ) + Akun UID yg baik dengan 7 digit/angka + Mount Red Eagle Fighting (15 hari ) + Mobil merah (Senilai 1388 koin emas) (Hadiah Ransel )*1 + 1000 Koin emas + 1000 Kacang emas</p>
      <h5>Top 2:</h5>
      <p>Lencana Gift King (31 hari ) + Mount Red Eagle Fighting (15 hari ) + Mobil merah (Senilai 1388 koin emas) (Hadiah Ransel )*1 + 800 Koin emas + 800 Kacang emas</p>
      <h5>Top 3:</h5>
      <p>Lencana Gift King (31 hari ) + Mount Red Eagle Fighting (15 hari ) + Mobil merah (Senilai 1388 koin emas) (Hadiah Ransel )*1 + 500 Koin emas + 500 Kacang emas</p>
      <h5>Top 4 - 5:</h5>
      <p>Lencana Gift King (31 hari ) + Mobil merah (Senilai 1388 koin emas) (Hadiah Ransel )*1 + 300 Koin emas + 300 Kacang emas</p>
      <h5>Top 6 - 10:</h5>
      <p>Mobil merah (Senilai 1388 koin emas) (Hadiah Ransel )*1 +200 Koin emas + 200 Kacang emas</p>
    </div>
    <h5>Hadiah untuk Top 10 dari Top Hegemon Kamar Karaoke:</h5>
    <div class="kRoomTop">
      <h5>Top 1:</h5>
      <p>Lencana Gift King (31 hari ) + Akun UID yg baik dengan 7 digit/angka + Mount Red Eagle Fighting (15 hari ) + Mobil merah (Senilai 1388 koin emas) (Hadiah Ransel )*1 + 1000 Koin emas + 1000 Kacang emas</p>
      <h5>Top 2:</h5>
      <p>Lencana Gift King (31 hari ) + Mount Red Eagle Fighting (15 hari ) + Mobil merah (Senilai 1388 koin emas) (Hadiah Ransel )*1 + 800 Koin emas + 800 Kacang emas</p>
      <h5>Top 3:</h5>
      <p>Lencana Gift King (31 hari ) + Mount Red Eagle Fighting (15 hari ) + Mobil merah (Senilai 1388 koin emas) (Hadiah Ransel )*1 + 500 Koin emas + 500 Kacang emas</p>
      <h5>Top 4 - 5:</h5>
      <p>Lencana Gift King (31 hari ) + Mobil merah (Senilai 1388 koin emas) (Hadiah Ransel )*1 + 300 Koin emas + 300 Kacang emas</p>
      <h5>Top 6 - 10:</h5>
      <p>Mobil merah (Senilai 1388 koin emas) (Hadiah Ransel )*1 +200 Koin emas + 200 Kacang emas</p>
    </div>
    <h5>Hadiah untuk Top 10 dari Top Hegemon Popularitas:</h5>
    <div class="kRoomTop">
      <h5>Top 1:</h5>
      <p>Lencana Popular King (31 hari ) + Kincir Ria (Senilai 388 koin emas) (Hadiah Ransel )*1 + VIP Member (30 hari ) + 1000 koin emas + 1000 Kacang emas</p>
      <h5>Top 2:</h5>
      <p>Lencana Popular King (31 hari ) + Kincir Ria (Senilai 388 koin emas) (Hadiah Ransel )*1 + VIP Member (30 hari ) + 800 koin emas + 800 Kacang emas</p>
      <h5>Top 3:</h5>
      <p>Lencana Popular King (31 hari ) + Kincir Ria (Senilai 388 koin emas) (Hadiah Ransel )*1 + VIP Member (30 hari ) + 600 koin emas + 600 Kacang emas</p>
      <h5>Top 4 - 5:</h5>
      <p>Lencana Popular King (31 hari ) + Kincir Ria (Senilai 388 koin emas) (Hadiah Ransel )*1 + VIP Member (30 hari ) + 300 koin emas + 300 Kacang emas</p>
      <h5>Top 6 - 10:</h5>
      <p> Kincir Ria (Senilai 388 koin emas) (Hadiah Ransel )*1 + VIP Member (30 hari ) + 200 koin emas + 200 Kacang emas</p>
    </div>
    <h5>Hadiah tentang kembalikan koin emas:</h5>
    <div class="fanhuan">
      <p>1.Jika memberikan/sawer hadiah ikat kepala kartun (10 koin emas), Bumper car (188 koin emas), Kincir Ria (388 koin emas) ke nyanyian terbuka yang diposting/diumumkan setelah mendaftar ikut acara,maka sistem akan kembilikan 5% koin emas dari jumlah koin emas hadiah kepada orang yang sawer pada besok pukul 0:00:00. Misalnya,hari ini kamu sawer hadiah Bumper car senilai 188 koin emas,maka sistem akan memberikan bonus 10 koin emas kepada kamu pada besok pukul 0:00:00</p>
      <p>2.Jika memberikan/sawer hadiah Fan kartun (10 koin emas), Pirate ship (188 koin emas), Roller coaster(388 koin emas) kepada pengguna yang bernyanyi di kamar karaoke setelah mendaftar ikut acara,maka sistem akan kembilikan 5% koin emas dari jumlah koin emas hadiah kepada orang yang sawer pada besok pukul 0:00:00. Misalnya,hari ini kamu sawer hadiah Pirate ship senilai 188 koin emas,maka sistem akan memberikan bonus 10 koin emas kepada kamu pada besok pukul 0:00:00</p>
    </div>
    <h5>Keterangan Hadiah:</h5>
    <p>1.Pengguna yang mendapatkan akun UID yg baik dengan 7 digit/angka,petugas Wekara ( ID 10) akan menghubungi kamu,kamu bisa pilih salah satu akun yang baik dengan 7 digit/angka yang diberikan oleh pihak Wekara, dan kamu perlu memberikan nomor HP yang belum terdaftar di platform Wekara untuk pengikatan.</p>
    <p>2.Hadiah ransel yang didapatkan dari acara ini, versi Android dapat dilihat/cek di halaman Saya - Ransel !</p>
    <p class="lastMsg">Hak interpretasi akhir dari acara ini dipegang oleh penyelenggara acara</p>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.wards {
  p {
    font-size: 80%;
    line-height: 0.36rem;
  }
  .activeTime {
    color: #6ffff3;
    text-align: center;
    margin-top: 0.51rem;
  }
  > h5 {
    text-align: center;
    font-size: 120%;
    color: #ffed6a;
    margin-top: 0.57rem;
  }
  .wardTop {
    > h5 {
      color: #6ffff3;
      font-size: 80%;
      margin-top: 0.2rem;
    }
    p {
      font-size: 80%;
    }
  }
  .kRoomTop {
    > h5 {
      color: #6ffff3;
      font-size: 80%;
      margin-top: 0.2rem;
    }
  }
  .fanhuan {
    p {
      margin-top: 0.27rem;
    }
  }
  .lastMsg {
    margin-top: 1rem;
    text-align: center;
  }
}
</style>
