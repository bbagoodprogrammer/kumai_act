const vietnamLang = {
    superbandit:"Mesin Slot Super", //超級老虎機
    triple_prize:"3 kali lipat hadiah undian tidak berhenti",  //3倍獎勵抽不停
    activity_time:"Waktu Acara Pukul 18:00 tgl 16 Aug~Pukul 21:00 tgl 26 Aug",  // 活动时间
    activity_rules:"Aturan Acara>>", //活动规则》》
    draw_record:"Catatan undian>>",  //抽獎記錄>>
    my_knapsack:"Ransel saya>>",  //我的背包
    stored_value:"Nạp ngay",  //前去储值
    draw_time:"Waktu Acara", //抽奖时间
    winning_prizes:"Mendapatkan hadiah",  //获得奖品
}
export default vietnamLang