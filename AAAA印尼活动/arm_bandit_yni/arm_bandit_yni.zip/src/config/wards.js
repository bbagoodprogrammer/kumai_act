const wards = {
    1: "Kotak musik",   //語聊房揹包禮物
    2: "boneka", //作品揹包禮物
    3: "Bunga sakura", //Ｋ房揹包禮物
    4: "3%Kupon bonus untuk top up", //3%储值返利券
    5: "5%Kupon bonus untuk top up", //5%储值返利券
    6: "10%Kupon bonus untuk top up", //10%储值返利券
    7: "Kupon untuk sawer 150 bonus 30", //150返30送礼返利券
    8: "Kupon untuk sawer 500 bonus 120", //500返120送礼返利券
    9: "Kupon untuk sawer 1000 bonus 300", //1000返300送礼返利券
    10: "50Koin harimau", //50老虎币
    11: "100Koin harimau", //100老虎币
    12: "150Koin harimau", //150老虎币
    13: "10Koin emas", //10金币
    14: "20Koin emas", //20金币
    15: "30Koin emas", //30金币
    16: "50Koin emas", //50金币
    17: "60Koin emas", //60金币
    18: "20Kacang emas", //20金豆
    19: "50Kacang emas",  //50金豆
    20: "80Kacang emas", //80金豆
    21: "100Kacang emas", //100金豆
    22: "150Kacang emas", //150金豆
    23: "200Kacang emas", //200金豆
    24: "Mount Audi", //骑士贵族
    25: "Mount BMW", //子爵贵族
    26: "Mount Bugatti", //伯爵贵族
    27: "VIP (3 hari)", //会员3天
    28: "akun UID yang baik dengan 7 digit/angka", //8位靓号
    29: "Double Card", //double卡
    30: "ID unik 4 digit", //四位靚號
}
export default wards